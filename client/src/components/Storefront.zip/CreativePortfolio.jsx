
import React from "react";
import { QRCodeCanvas } from "qrcode.react";

import {
  MapPin,
  Phone,
  Mail,
  Globe,
  MessageCircle,
  Share2,
  UserRound,
  CheckCircle2,
  Clock,
  Download,
  Image as ImageIcon,
  ArrowUpRight,
  BriefcaseBusiness,
  Code2,
  Palette,
  Headset,
  ScanLine,
  Send,
  Layers,
  Sparkles,
  ExternalLink,
  ShoppingBag,
  Zap,
  Instagram,
} from "lucide-react";

import {
  FaInstagram,
  FaLinkedinIn,
  FaFacebookF,
  FaYoutube,
  FaWhatsapp,
  FaTelegram,
  FaXTwitter,
  FaLink,
} from "react-icons/fa6";

// ============================================
// CREATIVE PORTFOLIO LAYOUT
// Dark Creative + Electric Cyan
// Responsive: Mobile, Tablet and Desktop
// ============================================

const CreativePortfolio = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],

  qrTargetUrl = "",
  qrFetching = false,

  formData = {
    name: "",
    phone: "",
    email: "",
    message: "",
  },

  setFormData = () => {},
  onFormSubmit = () => {},

  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,

  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "",
    role = "",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = null,
    avatar = null,
    banner = null,
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const socialIconMap = {
    instagram: FaInstagram,
    linkedin: FaLinkedinIn,
    facebook: FaFacebookF,
    youtube: FaYoutube,
    whatsapp: FaWhatsapp,
    telegram: FaTelegram,
    twitter: FaXTwitter,
  };

  const getSocialIcon = (platform = "") => {
    const key = platform.toLowerCase();

    const found = Object.keys(socialIconMap).find((item) =>
      key.includes(item)
    );

    return found ? socialIconMap[found] : FaLink;
  };

  const normalizeUrl = (url = "") => {
    if (!url) return "#";

    return /^https?:\/\//i.test(url)
      ? url
      : `https://${url}`;
  };

  const services = [
    {
      number: "01",
      title: "Web Development",
      description: "Building modern, fast and responsive digital experiences.",
      icon: Code2,
    },
    {
      number: "02",
      title: "UI/UX Design",
      description: "Creating intuitive interfaces with beautiful details.",
      icon: Palette,
    },
    {
      number: "03",
      title: "Creative Branding",
      description: "Giving businesses a unique and memorable identity.",
      icon: Sparkles,
    },
    {
      number: "04",
      title: "Digital Solutions",
      description: "Smart technology solutions for growing businesses.",
      icon: Layers,
    },
  ];

  const inputClass =
    "w-full rounded-xl border border-[#253B4F] bg-[#101D2A] px-4 py-3.5 text-sm text-white placeholder:text-slate-500 outline-none transition focus:border-[#22D3EE] focus:ring-2 focus:ring-cyan-400/10 disabled:opacity-50";

  const panelClass =
    "rounded-2xl border border-[#24394B] bg-[#101D2A] p-5 sm:p-6";

  return (
    <div className="creative-portfolio w-full overflow-hidden rounded-[20px] border border-[#24394B] bg-[#07131F] text-white shadow-2xl shadow-black/30 sm:rounded-[28px]">

      {/* ================================== */}
      {/* NAVBAR */}
      {/* ================================== */}

      <header className="border-b border-[#24394B] bg-[#091724] px-5 py-4 sm:px-8 lg:px-10">

        <div className="flex items-center justify-between gap-4">

          <div className="flex min-w-0 items-center gap-2.5">

            {logo ? (
              <img
                src={logo}
                alt="Business logo"
                className="h-9 w-9 rounded-lg border border-[#29475B] bg-white object-contain p-1"
              />
            ) : (
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#22D3EE] text-[#07131F]">
                <Zap size={20} fill="currentColor" />
              </div>
            )}

            <span className="text-xl font-black tracking-tight text-white">
              CREATIVE<span className="text-[#22D3EE]">.</span>
            </span>

          </div>

          <nav className="hidden items-center gap-6 lg:flex">

            {[
              ["Home", "#creative-home"],
              ["About", "#creative-about"],
              ["Services", "#creative-services"],
              ["Work", "#creative-work"],
              ["Contact", "#creative-contact"],
            ].map(([label, href]) => (
              <a
                key={label}
                href={href}
                className="text-xs font-semibold text-slate-400 transition hover:text-[#22D3EE]"
              >
                {label}
              </a>
            ))}

          </nav>

          <div className="flex shrink-0 items-center gap-2">

            <button
              type="button"
              onClick={onShare}
              aria-label="Share profile"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#29475B] text-slate-300 transition hover:border-[#22D3EE] hover:text-[#22D3EE]"
            >
              <Share2 size={16} />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex items-center gap-1.5 rounded-xl bg-[#22D3EE] px-3.5 py-2.5 text-xs font-black text-[#07131F] transition hover:bg-[#67E8F9]"
            >
              <ScanLine size={15} />
              My QR
            </button>

          </div>

        </div>

      </header>

      {/* ================================== */}
      {/* HERO SECTION */}
      {/* ================================== */}

      <section
        id="creative-home"
        className="relative overflow-hidden px-5 py-10 sm:px-8 sm:py-14 lg:px-10 lg:py-16"
      >

        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan-400/10 blur-[100px]" />

        <div className="pointer-events-none absolute -bottom-24 left-1/4 h-64 w-64 rounded-full bg-blue-500/10 blur-[100px]" />

        <div className="relative grid items-center gap-9 md:grid-cols-12 md:gap-10">

          {/* HERO CONTENT */}

          <div className="order-2 md:order-1 md:col-span-7">

            <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-2">

              <span className="h-2 w-2 rounded-full bg-[#22D3EE] shadow-[0_0_10px_#22D3EE]" />

              <span className="text-[10px] font-bold uppercase tracking-[2px] text-[#22D3EE]">
                Available for opportunities
              </span>

            </div>

            <p className="mt-7 text-sm font-medium text-slate-400">
              Hello, I'm
            </p>

            <div className="mt-2 flex flex-wrap items-center gap-2">

              <h1 className="text-4xl font-black leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
                {name || "Your Name"}
                <span className="text-[#22D3EE]">.</span>
              </h1>

              {isVerified && (
                <CheckCircle2
                  size={23}
                  className="fill-[#22D3EE] text-[#07131F]"
                  title="Verified Profile"
                />
              )}

            </div>

            <h2 className="mt-3 text-lg font-bold text-[#22D3EE] sm:text-xl">
              {role || "Creative Developer & Designer"}
            </h2>

            <p className="mt-5 max-w-xl text-sm leading-7 text-slate-400">
              {about ||
                "I transform creative ideas into meaningful digital experiences. Passionate about design, technology and building things that make an impact."}
            </p>

            {location && (
              <p className="mt-4 flex items-center gap-2 text-xs text-slate-400">
                <MapPin size={14} className="text-[#22D3EE]" />
                {location}
              </p>
            )}

            <div className="mt-7 flex flex-wrap gap-3">

              {visibleButtons.length > 0 ? (
                visibleButtons.map((button, index) => (
                  <button
                    key={button._id || button.id || index}
                    type="button"
                    onClick={() => onConfiguredButton(button)}
                    className={`flex items-center gap-2 rounded-xl px-5 py-3 text-xs font-bold transition sm:text-sm ${
                      button.actionType === "whatsapp"
                        ? "bg-emerald-500 text-white hover:bg-emerald-400"
                        : button.actionType === "call"
                          ? "bg-[#22D3EE] text-[#07131F] hover:bg-[#67E8F9]"
                          : "border border-[#29475B] bg-[#101D2A] text-white hover:border-[#22D3EE] hover:text-[#22D3EE]"
                    }`}
                  >
                    {button.label}
                    <ArrowUpRight size={15} />
                  </button>
                ))
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => onContactClick("phone")}
                    className="flex items-center gap-2 rounded-xl bg-[#22D3EE] px-5 py-3 text-xs font-black text-[#07131F] transition hover:bg-[#67E8F9] sm:text-sm"
                  >
                    Let's Talk
                    <ArrowUpRight size={16} />
                  </button>

                  <button
                    type="button"
                    onClick={onShare}
                    className="flex items-center gap-2 rounded-xl border border-[#29475B] px-5 py-3 text-xs font-bold text-white transition hover:border-[#22D3EE] hover:text-[#22D3EE] sm:text-sm"
                  >
                    <Share2 size={15} />
                    Share Profile
                  </button>
                </>
              )}

            </div>

            {socialLinks.length > 0 && (
              <div className="mt-7 flex flex-wrap gap-2">

                {socialLinks.map((social, index) => {
                  const Icon = getSocialIcon(social.platform);

                  return (
                    <a
                      key={social._id || `${social.platform}-${index}`}
                      href={normalizeUrl(social.url)}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={social.platform}
                      className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#29475B] bg-[#101D2A] text-slate-400 transition hover:-translate-y-1 hover:border-[#22D3EE] hover:text-[#22D3EE]"
                    >
                      <Icon size={17} />
                    </a>
                  );
                })}

              </div>
            )}

          </div>

          {/* HERO IMAGE */}

          <div className="order-1 md:order-2 md:col-span-5">

            <div className="relative mx-auto max-w-[330px] md:ml-auto md:mr-0">

              <div className="absolute -right-3 -top-3 h-28 w-28 rounded-2xl border border-cyan-400/20 bg-cyan-400/5 sm:-right-5 sm:-top-5 sm:h-36 sm:w-36" />

              <div className="absolute -bottom-4 -left-4 h-24 w-24 rounded-full border border-cyan-400/20" />

              <div className="relative aspect-[4/4.5] overflow-hidden rounded-2xl border border-[#29475B] bg-[#101D2A]">

                {avatar ? (
                  <img
                    src={avatar}
                    alt={name || "Profile"}
                    className="h-full w-full object-cover"
                  />
                ) : banner ? (
                  <img
                    src={banner}
                    alt="Profile banner"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <UserRound size={80} className="text-slate-600" />
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-[#07131F]/70 via-transparent to-transparent" />

                <div className="absolute bottom-5 left-5 right-5">

                  <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#22D3EE]">
                    Creative Mind
                  </p>

                  <p className="mt-1 text-lg font-black text-white">
                    {businessName || "My Creative Space"}
                  </p>

                </div>

              </div>

              <div className="absolute -right-3 top-1/2 flex h-14 w-14 -translate-y-1/2 items-center justify-center rounded-2xl border border-cyan-400/20 bg-[#101D2A] text-[#22D3EE] shadow-xl sm:-right-6">
                <Sparkles size={25} />
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* STATS */}
      {/* ================================== */}

      <section className="border-y border-[#24394B] bg-[#0C1B29] px-5 py-6 sm:px-8 lg:px-10">

        <div className="grid grid-cols-3 gap-3">

          {[
            {
              value: "2+",
              label: "Years Experience",
            },
            {
              value: `${productList.length}+`,
              label: "Projects / Products",
            },
            {
              value: "100%",
              label: "Client Focus",
            },
          ].map((item, index) => (
            <div
              key={item.label}
              className={`text-center ${
                index !== 2 ? "border-r border-[#29475B]" : ""
              }`}
            >

              <h3 className="text-2xl font-black text-[#22D3EE] sm:text-3xl">
                {item.value}
              </h3>

              <p className="mt-1 text-[9px] font-medium text-slate-500 sm:text-xs">
                {item.label}
              </p>

            </div>
          ))}

        </div>

      </section>

      {/* ================================== */}
      {/* ABOUT */}
      {/* ================================== */}

      <section
        id="creative-about"
        className="px-5 py-10 sm:px-8 sm:py-14 lg:px-10"
      >

        <div className="grid items-center gap-8 md:grid-cols-12 md:gap-10">

          <div className="md:col-span-7">

            <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
              01 / About Me
            </p>

            <h2 className="mt-3 text-3xl font-black tracking-tight text-white sm:text-4xl">
              Designing Ideas.
              <br />
              <span className="text-[#22D3EE]">
                Building Impact.
              </span>
            </h2>

            <p className="mt-5 text-sm leading-7 text-slate-400">
              {about ||
                "I believe every great idea deserves a beautiful digital experience. I combine creative thinking with modern technology to build meaningful products and experiences."}
            </p>

            {industry && (
              <span className="mt-5 inline-flex rounded-lg border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs font-semibold text-[#22D3EE]">
                {industry}
              </span>
            )}

            {businessName && (
              <p className="mt-3 text-xs font-semibold text-slate-400">
                {businessName}
              </p>
            )}

          </div>

          <div className="md:col-span-5">

            <div className="relative overflow-hidden rounded-2xl border border-[#29475B] bg-[#101D2A]">

              {banner ? (
                <img
                  src={banner}
                  alt="Creative workspace"
                  loading="lazy"
                  className="h-56 w-full object-cover sm:h-64"
                />
              ) : (
                <div className="flex h-56 items-center justify-center sm:h-64">
                  <Palette size={65} className="text-[#22D3EE]/40" />
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-[#07131F]/70 to-transparent" />

              <div className="absolute bottom-5 left-5">
                <p className="text-xs font-bold uppercase tracking-[2px] text-[#22D3EE]">
                  Think. Create. Inspire.
                </p>
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* SERVICES */}
      {/* ================================== */}

      <section
        id="creative-services"
        className="bg-[#0C1B29] px-5 py-10 sm:px-8 sm:py-14 lg:px-10"
      >

        <div className="mb-7 flex items-end justify-between gap-3">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
              02 / What I Do
            </p>

            <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
              My Expertise
            </h2>
          </div>

          <Sparkles size={25} className="text-[#22D3EE]" />

        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">

          {services.map((service) => (
            <div
              key={service.number}
              className="group rounded-2xl border border-[#29475B] bg-[#101D2A] p-5 transition duration-300 hover:-translate-y-1 hover:border-[#22D3EE]/60"
            >

              <div className="flex items-center justify-between">

                <span className="text-xs font-bold text-[#22D3EE]">
                  {service.number}
                </span>

                <service.icon
                  size={22}
                  className="text-slate-500 transition group-hover:text-[#22D3EE]"
                />

              </div>

              <h3 className="mt-6 text-sm font-bold text-white">
                {service.title}
              </h3>

              <p className="mt-2 text-xs leading-6 text-slate-500">
                {service.description}
              </p>

              <div className="mt-5 h-0.5 w-8 rounded-full bg-[#22D3EE] transition-all group-hover:w-16" />

            </div>
          ))}

        </div>

      </section>

      {/* ================================== */}
      {/* FEATURED PRODUCTS */}
      {/* ================================== */}

      {productList.length > 0 && (
        <section
          id="creative-work"
          className="px-5 py-10 sm:px-8 sm:py-14 lg:px-10"
        >

          <div className="mb-7 flex items-end justify-between gap-3">

            <div>
              <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
                03 / Selected Work
              </p>

              <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
                Featured Collection
              </h2>
            </div>

            <span className="rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1.5 text-xs font-bold text-[#22D3EE]">
              {productList.length} Items
            </span>

          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">

            {productList.map((product, index) => {
              const cover = product.images?.find(
                (item) => item?.url
              )?.url;

              return (
                <button
                  key={product._id}
                  type="button"
                  onClick={() => onProductClick(product)}
                  className="group overflow-hidden rounded-2xl border border-[#29475B] bg-[#101D2A] text-left transition duration-300 hover:-translate-y-1 hover:border-[#22D3EE]/60"
                >

                  <div className="relative h-48 overflow-hidden bg-[#0C1B29]">

                    {cover ? (
                      <img
                        src={cover}
                        alt={product.name}
                        loading="lazy"
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <ImageIcon size={40} className="text-slate-600" />
                      </div>
                    )}

                    <div className="absolute left-3 top-3 rounded-lg border border-white/10 bg-[#07131F]/80 px-3 py-1.5 backdrop-blur">
                      <span className="text-[10px] font-bold text-[#22D3EE]">
                        PROJECT 0{index + 1}
                      </span>
                    </div>

                    <span className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-xl bg-[#22D3EE] text-[#07131F]">
                      <ArrowUpRight size={17} />
                    </span>

                  </div>

                  <div className="p-4">

                    <h3 className="truncate text-sm font-bold text-white">
                      {product.name}
                    </h3>

                    <p className="mt-2 line-clamp-2 text-xs leading-5 text-slate-500">
                      {product.description}
                    </p>

                    <div className="mt-4 flex items-center justify-between">

                      <p className="text-base font-black text-[#22D3EE]">
                        ₹{Number(product.price || 0).toLocaleString("en-IN")}
                      </p>

                      <span className="flex items-center gap-1 text-xs font-bold text-slate-400 transition group-hover:text-[#22D3EE]">
                        Explore
                        <ArrowUpRight size={14} />
                      </span>

                    </div>

                  </div>

                </button>
              );
            })}

          </div>

        </section>
      )}

      {/* ================================== */}
      {/* GALLERY */}
      {/* ================================== */}

      <section className="bg-[#0C1B29] px-5 py-10 sm:px-8 sm:py-14 lg:px-10">

        <div className="mb-7 flex items-end justify-between gap-3">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
              04 / Visual Stories
            </p>

            <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
              Creative Gallery
            </h2>
          </div>

          <span className="text-xs font-semibold text-slate-500">
            {galleryImages.length} Photos
          </span>

        </div>

        {galleryImages.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">

            {galleryImages.map((image, index) => (
              <button
                key={`${image.url}-${index}`}
                type="button"
                onClick={() => onGalleryClick(image)}
                className="group relative aspect-[4/3] overflow-hidden rounded-xl border border-[#29475B] bg-[#101D2A]"
              >

                <img
                  src={image.url}
                  alt={image.alt || `Gallery ${index + 1}`}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                />

                <div className="absolute inset-0 flex items-center justify-center bg-[#07131F]/60 opacity-0 transition group-hover:opacity-100">
                  <ArrowUpRight size={26} className="text-[#22D3EE]" />
                </div>

              </button>
            ))}

          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-[#29475B] py-12 text-center">

            <ImageIcon size={40} className="mx-auto text-slate-600" />

            <p className="mt-3 text-sm text-slate-500">
              No gallery images added yet.
            </p>

          </div>
        )}

      </section>

      {/* ================================== */}
      {/* CONTACT INFORMATION */}
      {/* ================================== */}

      <section className="px-5 py-10 sm:px-8 sm:py-14 lg:px-10">

        <div className="mb-6">

          <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
            05 / Contact Details
          </p>

          <h2 className="mt-2 text-2xl font-black text-white sm:text-3xl">
            Let's Connect
          </h2>

        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {[
            {
              Icon: Phone,
              label: "Phone",
              value: phone,
              type: "phone",
            },
            {
              Icon: MessageCircle,
              label: "WhatsApp",
              value: whatsapp,
              type: "whatsapp",
            },
            {
              Icon: Mail,
              label: "Email",
              value: email,
              type: "email",
            },
            {
              Icon: Globe,
              label: "Website",
              value: website,
              type: "website",
            },
            {
              Icon: MapPin,
              label: "Address",
              value: address,
              type: "address",
            },
            {
              Icon: Clock,
              label: "Business Hours",
              value: businessHours,
              type: "hours",
            },
          ]
            .filter((item) => item.value)
            .map((item) => (
              <button
                key={item.type}
                type="button"
                onClick={() => {
                  if (item.type !== "hours") {
                    onContactClick(item.type);
                  }
                }}
                className="flex min-w-0 items-start gap-3 rounded-xl border border-[#29475B] bg-[#101D2A] p-4 text-left transition hover:border-[#22D3EE]/60"
              >

                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-400/10 text-[#22D3EE]">
                  <item.Icon size={17} />
                </div>

                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    {item.label}
                  </p>

                  <p className="mt-1 break-words text-xs font-semibold leading-5 text-slate-200">
                    {item.value}
                  </p>
                </div>

              </button>
            ))}

        </div>

      </section>

      {/* ================================== */}
      {/* INQUIRY FORM */}
      {/* ================================== */}

      <section
        id="creative-contact"
        className="border-y border-[#29475B] bg-[#0C1B29] px-5 py-10 sm:px-8 sm:py-14 lg:px-10"
      >

        <div className="grid items-start gap-8 lg:grid-cols-12">

          <div className="lg:col-span-4">

            <p className="text-[10px] font-bold uppercase tracking-[3px] text-[#22D3EE]">
              Have an idea?
            </p>

            <h2 className="mt-3 text-3xl font-black leading-tight text-white">
              Let's Make
              <br />
              Something
              <br />
              <span className="text-[#22D3EE]">Awesome.</span>
            </h2>

            <p className="mt-5 text-sm leading-7 text-slate-400">
              Have a project or collaboration in mind? Send me a message.
              Let's create something meaningful together.
            </p>

            <div className="mt-6 flex items-center gap-3">

              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-400/10 text-[#22D3EE]">
                <Mail size={18} />
              </div>

              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                  Email
                </p>

                <p className="text-sm font-bold text-white">
                  {email || "Send an inquiry"}
                </p>
              </div>

            </div>

          </div>

          <div className="rounded-2xl border border-[#29475B] bg-[#101D2A] p-5 sm:p-7 lg:col-span-8">

            {formSubmitted ? (
              <div className="py-8 text-center">

                <CheckCircle2
                  size={42}
                  className="mx-auto text-emerald-400"
                />

                <h3 className="mt-4 text-lg font-bold text-white">
                  Inquiry Submitted Successfully!
                </h3>

                <p className="mt-2 text-sm text-slate-400">
                  Thank you for contacting me. I'll get back to you soon.
                </p>

              </div>
            ) : (
              <form
                onSubmit={onFormSubmit}
                className="space-y-4"
              >

                {inquirySubmitError && (
                  <div className="rounded-xl border border-red-400/20 bg-red-400/10 p-3 text-sm text-red-300">
                    {inquirySubmitError}
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">

                  <input
                    type="text"
                    required
                    placeholder="Your Name"
                    value={formData.name}
                    disabled={inquirySubmitting}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        name: e.target.value,
                      })
                    }
                    className={inputClass}
                  />

                  <input
                    type="tel"
                    required
                    placeholder="Phone Number"
                    value={formData.phone}
                    disabled={inquirySubmitting}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        phone: e.target.value,
                      })
                    }
                    className={inputClass}
                  />

                </div>

                <input
                  type="email"
                  placeholder="Email Address (Optional)"
                  value={formData.email}
                  disabled={inquirySubmitting}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      email: e.target.value,
                    })
                  }
                  className={inputClass}
                />

                <textarea
                  rows={4}
                  required
                  placeholder="Tell me about your project..."
                  value={formData.message}
                  disabled={inquirySubmitting}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      message: e.target.value,
                    })
                  }
                  className={`${inputClass} resize-none`}
                />

                <button
                  type="submit"
                  disabled={inquirySubmitting}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#22D3EE] py-3.5 text-sm font-black text-[#07131F] transition hover:bg-[#67E8F9] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {inquirySubmitting ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send size={17} />
                      Send Message
                    </>
                  )}
                </button>

              </form>
            )}

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* QR CODE */}
      {/* ================================== */}

      {qrTargetUrl && (
        <section className="border-b border-[#24394B] bg-[#091724] px-5 py-8 text-center sm:px-8">

          <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-400/10 text-[#22D3EE]">
            <ScanLine size={22} />
          </div>

          <h2 className="mt-3 text-lg font-bold text-white">
            Scan My Digital Profile
          </h2>

          <p className="mt-1 text-xs text-slate-500">
            Connect with me in seconds
          </p>

          <div className="mx-auto mt-5 flex w-fit items-center justify-center rounded-xl bg-white p-3">

            {qrFetching ? (
              <p className="p-8 text-xs text-slate-500">
                Loading QR...
              </p>
            ) : (
              <QRCodeCanvas
                id="creative-portfolio-qr"
                value={qrTargetUrl}
                size={150}
                level="H"
                includeMargin
              />
            )}

          </div>

          {!qrFetching && (
            <a
              href={`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(qrTargetUrl)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-xs font-bold text-[#22D3EE] hover:text-white"
            >
              <Download size={15} />
              Download QR Code
            </a>
          )}

        </section>
      )}

      {/* ================================== */}
      {/* FOOTER */}
      {/* ================================== */}

      <footer className="bg-[#07111B] px-5 py-7 sm:px-8 lg:px-10">

        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">

          <div className="text-center sm:text-left">

            <p className="text-xl font-black tracking-tight text-white">
              CREATIVE<span className="text-[#22D3EE]">.</span>
            </p>

            <p className="mt-1 text-[10px] text-slate-500">
              Think. Create. Inspire.
            </p>

          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">

            {[
              ["Home", "#creative-home"],
              ["About", "#creative-about"],
              ["Services", "#creative-services"],
              ["Work", "#creative-work"],
              ["Contact", "#creative-contact"],
            ].map(([label, href]) => (
              <a
                key={label}
                href={href}
                className="text-[11px] font-semibold text-slate-500 transition hover:text-[#22D3EE]"
              >
                {label}
              </a>
            ))}

          </div>

          <p className="text-center text-[10px] text-slate-600">
            © {new Date().getFullYear()} {name || businessName}. All rights reserved.
          </p>

        </div>

        <div className="mt-5 border-t border-[#24394B] pt-4 text-center">

          <p className="text-[10px] text-slate-600">
            Powered by{" "}
            <span className="font-bold text-[#22D3EE]">
              BioWebsite
            </span>
          </p>

        </div>

      </footer>

    </div>
  );
};

export default CreativePortfolio;
