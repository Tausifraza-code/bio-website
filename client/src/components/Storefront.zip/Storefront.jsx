import React from "react";
import { QRCodeCanvas } from "qrcode.react";
import {
  FaPhone,
  FaWhatsapp,
  FaEnvelope,
  FaGlobe,
  FaLocationDot,
  FaShareNodes,
  FaQrcode,
  FaInstagram,
  FaFacebookF,
  FaLinkedinIn,
  FaYoutube,
  FaXTwitter,
  FaArrowRight,
  FaCartShopping,
  FaClock,
  FaCheck,
} from "react-icons/fa6";

const Storefront = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],
  qrTargetUrl = "",
  qrFetching = false,
  formData = { name: "", phone: "", email: "", message: "" },
  setFormData = () => {},
  onFormSubmit = () => {},
  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,
  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "Your Business",
    role = "",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = "",
    avatar = "",
    banner = "",
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const displayName = businessName || name || "Your Business";
  const displayRole = role || industry || "Quality Products & Services";

  const getImageUrl = (image) => {
    if (!image) return "";

    if (typeof image === "string") return image;

    return image.url || image.imageUrl || image.src || "";
  };

  const getProductImage = (product) => {
    if (!product) return "";

    if (product.images?.length > 0) {
      return getImageUrl(product.images[0]);
    }

    return getImageUrl(product.image);
  };

  const getSocialIcon = (platform) => {
    const value = String(platform || "").toLowerCase();

    if (value.includes("instagram")) return <FaInstagram />;
    if (value.includes("facebook")) return <FaFacebookF />;
    if (value.includes("linkedin")) return <FaLinkedinIn />;
    if (value.includes("youtube")) return <FaYoutube />;
    if (value.includes("twitter") || value.includes("x.com"))
      return <FaXTwitter />;

    return <FaGlobe />;
  };

  const profileImage = getImageUrl(logo || avatar);
  const heroImage = getImageUrl(banner);

  const handleContact = (type) => {
    onContactClick(type);
  };

  return (
    <div className="min-h-screen bg-[#f7f7f5] text-[#202020]">
      {/* =====================================================
          TOP BAR
      ===================================================== */}
      <div className="border-b border-[#e8e5df] bg-[#1d1d1b] text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-2.5 text-xs sm:px-8">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-[#d6a84f]" />
            <span>{displayRole}</span>
          </div>

          {location && (
            <div className="hidden items-center gap-2 sm:flex">
              <FaLocationDot className="text-[#d6a84f]" />
              <span>{location}</span>
            </div>
          )}
        </div>
      </div>

      {/* =====================================================
          MAIN NAVBAR
      ===================================================== */}
      <header className="sticky top-0 z-40 border-b border-[#e8e5df] bg-[#f7f7f5]/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-4 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            {profileImage ? (
              <img
                src={profileImage}
                alt={displayName}
                className="h-12 w-12 rounded-xl border border-[#dedbd3] bg-white object-cover"
              />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#1d1d1b] text-lg font-black text-white">
                {displayName.charAt(0).toUpperCase()}
              </div>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="truncate text-base font-black">
                  {displayName}
                </h1>

                {isVerified && (
                  <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[#d6a84f] text-[8px] text-white">
                    <FaCheck />
                  </span>
                )}
              </div>

              <p className="truncate text-xs text-[#77736b]">
                {industry || displayRole}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onShare}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#dedbd3] bg-white transition hover:bg-[#1d1d1b] hover:text-white"
              title="Share"
            >
              <FaShareNodes />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#dedbd3] bg-white transition hover:bg-[#1d1d1b] hover:text-white"
              title="QR Code"
            >
              <FaQrcode />
            </button>
          </div>
        </div>
      </header>

      {/* =====================================================
          HERO / STORE COVER
      ===================================================== */}
      <section className="mx-auto max-w-7xl px-5 pt-5 sm:px-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-[#1d1d1b]">
          {heroImage && (
            <img
              src={heroImage}
              alt=""
              className="absolute inset-0 h-full w-full object-cover opacity-35"
            />
          )}

          <div className="absolute inset-0 bg-gradient-to-r from-[#1d1d1b] via-[#1d1d1b]/90 to-transparent" />

          <div className="relative grid min-h-[440px] items-center lg:grid-cols-[1fr_0.7fr]">
            <div className="px-7 py-14 sm:px-12 lg:px-16">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-xs font-bold uppercase tracking-wider text-white/80">
                <FaCartShopping className="text-[#d6a84f]" />
                Official Store
              </div>

              <h2 className="max-w-2xl text-4xl font-black leading-tight text-white sm:text-5xl lg:text-6xl">
                {displayName}
              </h2>

              <p className="mt-5 max-w-xl text-base leading-7 text-white/70">
                {about ||
                  "Discover our products, services and everything you need in one place."}
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                {phone && (
                  <button
                    type="button"
                    onClick={() => handleContact("phone")}
                    className="inline-flex items-center gap-2 rounded-xl bg-[#d6a84f] px-5 py-3 text-sm font-bold text-[#1d1d1b] transition hover:bg-white"
                  >
                    <FaPhone />
                    Call Store
                  </button>
                )}

                {whatsapp && (
                  <button
                    type="button"
                    onClick={() => handleContact("whatsapp")}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-bold text-white transition hover:bg-white hover:text-[#1d1d1b]"
                  >
                    <FaWhatsapp />
                    WhatsApp
                  </button>
                )}
              </div>
            </div>

            <div className="hidden h-full lg:block">
              {heroImage ? (
                <img
                  src={heroImage}
                  alt={displayName}
                  className="h-full min-h-[440px] w-full object-cover"
                />
              ) : profileImage ? (
                <div className="flex h-full items-center justify-center p-12">
                  <img
                    src={profileImage}
                    alt={displayName}
                    className="max-h-[350px] w-full rounded-3xl object-cover"
                  />
                </div>
              ) : (
                <div className="flex h-full items-center justify-center">
                  <div className="text-[160px] font-black text-white/5">
                    {displayName.charAt(0).toUpperCase()}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT STRIP
      ===================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-6 sm:px-8">
        <div className="grid overflow-hidden rounded-2xl border border-[#e4e0d8] bg-white sm:grid-cols-2 lg:grid-cols-4">
          {phone && (
            <button
              type="button"
              onClick={() => handleContact("phone")}
              className="group border-b border-[#e8e5df] p-5 text-left transition hover:bg-[#faf9f6] sm:border-r lg:border-b-0"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4f0e7] text-[#a27b27] group-hover:bg-[#1d1d1b] group-hover:text-white">
                  <FaPhone />
                </span>

                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#98948c]">
                    Call
                  </p>
                  <p className="mt-1 truncate text-sm font-bold">
                    {phone}
                  </p>
                </div>
              </div>
            </button>
          )}

          {email && (
            <button
              type="button"
              onClick={() => handleContact("email")}
              className="group border-b border-[#e8e5df] p-5 text-left transition hover:bg-[#faf9f6] lg:border-b-0 lg:border-r"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4f0e7] text-[#a27b27] group-hover:bg-[#1d1d1b] group-hover:text-white">
                  <FaEnvelope />
                </span>

                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#98948c]">
                    Email
                  </p>
                  <p className="mt-1 truncate text-sm font-bold">
                    {email}
                  </p>
                </div>
              </div>
            </button>
          )}

          {website && (
            <button
              type="button"
              onClick={() => handleContact("website")}
              className="group border-b border-[#e8e5df] p-5 text-left transition hover:bg-[#faf9f6] sm:border-r lg:border-b-0"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4f0e7] text-[#a27b27] group-hover:bg-[#1d1d1b] group-hover:text-white">
                  <FaGlobe />
                </span>

                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#98948c]">
                    Website
                  </p>
                  <p className="mt-1 truncate text-sm font-bold">
                    {website}
                  </p>
                </div>
              </div>
            </button>
          )}

          {(address || location) && (
            <button
              type="button"
              onClick={() => handleContact("address")}
              className="group p-5 text-left transition hover:bg-[#faf9f6]"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f4f0e7] text-[#a27b27] group-hover:bg-[#1d1d1b] group-hover:text-white">
                  <FaLocationDot />
                </span>

                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#98948c]">
                    Location
                  </p>
                  <p className="mt-1 line-clamp-1 text-sm font-bold">
                    {address || location}
                  </p>
                </div>
              </div>
            </button>
          )}
        </div>
      </section>

      {/* =====================================================
          CONFIGURED BUTTONS
      ===================================================== */}
      {visibleButtons.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-12 sm:px-8">
          <div className="mb-5 flex items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
                Quick Access
              </p>

              <h2 className="mt-1 text-2xl font-black">
                Store Links
              </h2>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {visibleButtons.map((button, index) => (
              <button
                key={button._id || button.id || index}
                type="button"
                onClick={() => onConfiguredButton(button)}
                className="flex items-center justify-between rounded-2xl border border-[#e4e0d8] bg-white px-5 py-4 text-left transition hover:border-[#d6a84f] hover:shadow-sm"
              >
                <span className="font-bold">
                  {button.label || "Open"}
                </span>

                <FaArrowRight className="text-[#a27b27]" />
              </button>
            ))}
          </div>
        </section>
      )}

      {/* =====================================================
          PRODUCTS
      ===================================================== */}
      {productList.length > 0 && (
        <section className="border-y border-[#e8e5df] bg-white">
          <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
            <div className="mb-8 flex items-end justify-between gap-5">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
                  Our Collection
                </p>

                <h2 className="mt-2 text-3xl font-black sm:text-4xl">
                  Featured Products
                </h2>
              </div>

              <div className="hidden text-sm text-[#8a867e] sm:block">
                {productList.length} Products
              </div>
            </div>

            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {productList.map((product, index) => {
                const image = getProductImage(product);

                return (
                  <button
                    key={product._id || product.id || index}
                    type="button"
                    onClick={() => onProductClick(product)}
                    className="group overflow-hidden rounded-3xl border border-[#e4e0d8] bg-[#faf9f6] text-left transition hover:-translate-y-1 hover:shadow-xl"
                  >
                    <div className="relative h-64 overflow-hidden bg-[#efede8]">
                      {image ? (
                        <img
                          src={image}
                          alt={product.name || "Product"}
                          className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-sm font-semibold text-[#aaa59b]">
                          No Image
                        </div>
                      )}

                      <div className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-[#1d1d1b] shadow-sm">
                        <FaArrowRight className="-rotate-45" />
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="flex items-start justify-between gap-4">
                        <h3 className="text-lg font-black">
                          {product.name || "Product"}
                        </h3>

                        {product.price !== undefined &&
                          product.price !== null &&
                          product.price !== "" && (
                            <span className="whitespace-nowrap text-base font-black text-[#a27b27]">
                              ₹{product.price}
                            </span>
                          )}
                      </div>

                      {product.description && (
                        <p className="mt-2 line-clamp-2 text-sm leading-6 text-[#77736b]">
                          {product.description}
                        </p>
                      )}

                      <div className="mt-5 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#a27b27]">
                        View Product
                        <FaArrowRight />
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          ABOUT
      ===================================================== */}
      {about && (
        <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
          <div className="grid gap-8 lg:grid-cols-[0.65fr_1.35fr]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
                About Us
              </p>

              <h2 className="mt-2 text-3xl font-black sm:text-4xl">
                More About Our Business
              </h2>
            </div>

            <div className="rounded-3xl bg-white p-7 shadow-sm ring-1 ring-[#e4e0d8]">
              <p className="text-sm leading-8 text-[#66625b]">
                {about}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          GALLERY
      ===================================================== */}
      {galleryImages.length > 0 && (
        <section className="bg-[#1d1d1b]">
          <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
            <div className="mb-8">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#d6a84f]">
                Visual Stories
              </p>

              <h2 className="mt-2 text-3xl font-black text-white sm:text-4xl">
                Our Gallery
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {galleryImages.map((image, index) => {
                const imageUrl = getImageUrl(image);

                return (
                  <button
                    key={image._id || image.id || index}
                    type="button"
                    onClick={() => onGalleryClick(image)}
                    className="group relative aspect-square overflow-hidden rounded-2xl bg-white/5"
                  >
                    {imageUrl && (
                      <img
                        src={imageUrl}
                        alt={image.alt || "Gallery"}
                        className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                      />
                    )}

                    <div className="absolute inset-0 bg-black/0 transition group-hover:bg-black/30" />
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          BUSINESS HOURS
      ===================================================== */}
      {businessHours && (
        <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
          <div className="flex flex-col gap-6 rounded-3xl border border-[#e4e0d8] bg-white p-7 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#f4f0e7] text-[#a27b27]">
                <FaClock />
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
                  Opening Hours
                </p>

                <p className="mt-2 whitespace-pre-line text-sm leading-7 text-[#66625b]">
                  {businessHours}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          SOCIAL
      ===================================================== */}
      {socialLinks.length > 0 && (
        <section className="border-t border-[#e8e5df] bg-[#faf9f6]">
          <div className="mx-auto max-w-7xl px-5 py-12 text-center sm:px-8">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
              Stay Connected
            </p>

            <h2 className="mt-2 text-3xl font-black">
              Follow Our Store
            </h2>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={social._id || social.id || index}
                  href={social.url || "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="flex h-12 w-12 items-center justify-center rounded-xl border border-[#dedbd3] bg-white text-[#1d1d1b] transition hover:bg-[#1d1d1b] hover:text-white"
                  title={social.platform || "Social"}
                >
                  {getSocialIcon(social.platform)}
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          QR
      ===================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid items-center gap-8 overflow-hidden rounded-[2rem] bg-[#1d1d1b] p-7 sm:p-10 lg:grid-cols-[1fr_auto]">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#d6a84f]">
              Digital Store
            </p>

            <h2 className="mt-2 text-3xl font-black text-white sm:text-4xl">
              Scan & Visit Us
            </h2>

            <p className="mt-4 max-w-xl text-sm leading-7 text-white/60">
              Share this QR code with your customers so they can quickly
              access your digital business profile.
            </p>

            <button
              type="button"
              onClick={onOpenQr}
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#d6a84f] px-5 py-3 text-sm font-bold text-[#1d1d1b] transition hover:bg-white"
            >
              <FaQrcode />
              Open QR
            </button>
          </div>

          <div className="flex justify-center">
            <div className="rounded-3xl bg-white p-4">
              {qrFetching ? (
                <div className="flex h-40 w-40 items-center justify-center text-xs text-[#8b877f]">
                  Loading...
                </div>
              ) : qrTargetUrl ? (
                <QRCodeCanvas
                  value={qrTargetUrl}
                  size={160}
                  includeMargin
                />
              ) : (
                <div className="flex h-40 w-40 items-center justify-center text-center text-xs text-[#8b877f]">
                  QR unavailable
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          INQUIRY
      ===================================================== */}
      <section className="border-t border-[#e8e5df] bg-white">
        <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
          <div className="grid gap-8 lg:grid-cols-[0.7fr_1.3fr]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#a27b27]">
                Get In Touch
              </p>

              <h2 className="mt-2 text-3xl font-black sm:text-4xl">
                Have a Question?
              </h2>

              <p className="mt-4 text-sm leading-7 text-[#77736b]">
                Send us your inquiry and our team will get back to you.
              </p>
            </div>

            <form
              onSubmit={onFormSubmit}
              className="rounded-3xl border border-[#e4e0d8] bg-[#faf9f6] p-6 sm:p-8"
            >
              {formSubmitted ? (
                <div className="flex min-h-[280px] flex-col items-center justify-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#d6a84f]/20 text-xl text-[#a27b27]">
                    <FaCheck />
                  </div>

                  <h3 className="mt-5 text-xl font-black">
                    Inquiry Submitted
                  </h3>

                  <p className="mt-2 text-sm text-[#77736b]">
                    Thank you. We will get back to you soon.
                  </p>
                </div>
              ) : (
                <>
                  {inquirySubmitError && (
                    <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
                      {inquirySubmitError}
                    </div>
                  )}

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[#77736b]">
                        Name
                      </label>

                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="Your name"
                        className="w-full rounded-xl border border-[#dedbd3] bg-white px-4 py-3 text-sm outline-none focus:border-[#d6a84f]"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[#77736b]">
                        Phone
                      </label>

                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            phone: e.target.value,
                          }))
                        }
                        placeholder="Phone number"
                        className="w-full rounded-xl border border-[#dedbd3] bg-white px-4 py-3 text-sm outline-none focus:border-[#d6a84f]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[#77736b]">
                        Email
                      </label>

                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            email: e.target.value,
                          }))
                        }
                        placeholder="Email address"
                        className="w-full rounded-xl border border-[#dedbd3] bg-white px-4 py-3 text-sm outline-none focus:border-[#d6a84f]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-[#77736b]">
                        Message
                      </label>

                      <textarea
                        rows={5}
                        value={formData.message}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            message: e.target.value,
                          }))
                        }
                        placeholder="Write your inquiry..."
                        className="w-full resize-none rounded-xl border border-[#dedbd3] bg-white px-4 py-3 text-sm outline-none focus:border-[#d6a84f]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={inquirySubmitting}
                    className="mt-6 w-full rounded-xl bg-[#1d1d1b] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#a27b27] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {inquirySubmitting ? "Sending..." : "Send Inquiry"}
                  </button>
                </>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* =====================================================
          FOOTER
      ===================================================== */}
      <footer className="bg-[#1d1d1b] text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-5 py-8 text-center sm:flex-row sm:px-8 sm:text-left">
          <div>
            <p className="font-black">{displayName}</p>
            <p className="mt-1 text-xs text-white/40">
              {industry || displayRole}
            </p>
          </div>

          <p className="text-xs text-white/40">
            Digital Business Profile
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Storefront;