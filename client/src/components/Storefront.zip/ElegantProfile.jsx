import React from "react";
import { QRCodeCanvas } from "qrcode.react";
import {
  FaArrowRight,
  FaCheck,
  FaClock,
  FaEnvelope,
  FaFacebookF,
  FaGlobe,
  FaInstagram,
  FaLinkedinIn,
  FaLocationDot,
  FaPhone,
  FaQrcode,
  FaShareNodes,
  FaWhatsapp,
  FaXTwitter,
  FaYoutube,
} from "react-icons/fa6";

const ElegantProfile = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],
  qrTargetUrl = "",
  qrFetching = false,
  formData = { name: "", phone: "", email: "", message: "" },
  setFormData = () => {},
  onFormSubmit = () => {},
  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,
  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "Your Name",
    role = "Professional",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = "",
    avatar = "",
    banner = "",
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const displayName = name || businessName || "Your Name";
  const displayRole = role || industry || "Professional";

  const getImageUrl = (image) => {
    if (!image) return "";

    if (typeof image === "string") return image;

    return image.url || image.imageUrl || image.src || "";
  };

  const getProductImage = (product) => {
    if (!product) return "";

    if (product.images?.length) {
      return getImageUrl(product.images[0]);
    }

    return getImageUrl(product.image);
  };

  const getSocialIcon = (platform) => {
    const value = String(platform || "").toLowerCase();

    if (value.includes("instagram")) return <FaInstagram />;
    if (value.includes("facebook")) return <FaFacebookF />;
    if (value.includes("linkedin")) return <FaLinkedinIn />;
    if (value.includes("youtube")) return <FaYoutube />;
    if (value.includes("twitter") || value.includes("x.com")) {
      return <FaXTwitter />;
    }

    return <FaGlobe />;
  };

  const profileImage = getImageUrl(avatar || logo);
  const heroImage = getImageUrl(banner);

  const handleContact = (type) => {
    onContactClick(type);
  };

  return (
    <div className="min-h-screen bg-[#f8f5ef] text-[#29251f]">
      {/* =====================================================
          HEADER
      ===================================================== */}
      <header className="border-b border-[#e7dfd2] bg-[#f8f5ef]/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
          <div className="flex min-w-0 items-center gap-4">
            {profileImage ? (
              <img
                src={profileImage}
                alt={displayName}
                className="h-12 w-12 rounded-full border border-[#d9cdbb] object-cover"
              />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#29251f] font-serif text-lg text-white">
                {displayName.charAt(0).toUpperCase()}
              </div>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p className="truncate font-serif text-lg font-semibold">
                  {displayName}
                </p>

                {isVerified && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#a27c45] text-[8px] text-white">
                    <FaCheck />
                  </span>
                )}
              </div>

              <p className="truncate text-xs tracking-wide text-[#8b8277]">
                {displayRole}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onShare}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-[#ddd3c5] bg-white text-[#665d53] transition hover:bg-[#29251f] hover:text-white"
            >
              <FaShareNodes />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-[#ddd3c5] bg-white text-[#665d53] transition hover:bg-[#29251f] hover:text-white"
            >
              <FaQrcode />
            </button>
          </div>
        </div>
      </header>

      {/* =====================================================
          HERO
      ===================================================== */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-20">
          <div className="grid items-center gap-12 lg:grid-cols-[1fr_0.85fr]">
            <div className="order-2 text-center lg:order-1 lg:text-left">
              <div className="mx-auto mb-6 h-px w-20 bg-[#a27c45] lg:mx-0" />

              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
                {industry || "Professional Profile"}
              </p>

              <h1 className="mt-5 font-serif text-5xl font-semibold leading-tight sm:text-6xl lg:text-7xl">
                {displayName}
              </h1>

              <p className="mt-5 font-serif text-xl italic text-[#766d62]">
                {displayRole}
              </p>

              {location && (
                <div className="mt-5 flex items-center justify-center gap-2 text-sm text-[#81786e] lg:justify-start">
                  <FaLocationDot className="text-[#a27c45]" />
                  {location}
                </div>
              )}

              {about && (
                <p className="mx-auto mt-7 max-w-xl text-sm leading-8 text-[#746c62] lg:mx-0">
                  {about}
                </p>
              )}

              <div className="mt-8 flex flex-wrap justify-center gap-3 lg:justify-start">
                {phone && (
                  <button
                    type="button"
                    onClick={() => handleContact("phone")}
                    className="inline-flex items-center gap-2 rounded-full bg-[#29251f] px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-[#a27c45]"
                  >
                    <FaPhone />
                    Contact Me
                  </button>
                )}

                {whatsapp && (
                  <button
                    type="button"
                    onClick={() => handleContact("whatsapp")}
                    className="inline-flex items-center gap-2 rounded-full border border-[#d7cbbb] bg-white px-6 py-3.5 text-sm font-semibold text-[#4f483f] transition hover:border-[#a27c45] hover:text-[#a27c45]"
                  >
                    <FaWhatsapp />
                    WhatsApp
                  </button>
                )}
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <div className="relative mx-auto max-w-md">
                <div className="absolute -inset-5 rounded-full border border-[#d9cdbb] opacity-60" />
                <div className="absolute -inset-10 rounded-full border border-[#e4dbce] opacity-60" />

                <div className="relative overflow-hidden rounded-[50%] border-[10px] border-[#f8f5ef] shadow-xl">
                  {heroImage ? (
                    <img
                      src={heroImage}
                      alt={displayName}
                      className="aspect-square w-full object-cover"
                    />
                  ) : profileImage ? (
                    <img
                      src={profileImage}
                      alt={displayName}
                      className="aspect-square w-full object-cover"
                    />
                  ) : (
                    <div className="flex aspect-square items-center justify-center bg-[#29251f]">
                      <span className="font-serif text-[150px] text-white/10">
                        {displayName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT DETAILS
      ===================================================== */}
      <section className="border-y border-[#e7dfd2] bg-white/60">
        <div className="mx-auto grid max-w-6xl sm:grid-cols-2 lg:grid-cols-4">
          {phone && (
            <button
              type="button"
              onClick={() => handleContact("phone")}
              className="group border-b border-[#e7dfd2] p-6 text-center transition hover:bg-[#f8f5ef] sm:border-r lg:border-b-0"
            >
              <FaPhone className="mx-auto text-[#a27c45]" />

              <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9b9287]">
                Phone
              </p>

              <p className="mt-1 truncate text-sm font-medium">
                {phone}
              </p>
            </button>
          )}

          {email && (
            <button
              type="button"
              onClick={() => handleContact("email")}
              className="group border-b border-[#e7dfd2] p-6 text-center transition hover:bg-[#f8f5ef] lg:border-b-0 lg:border-r"
            >
              <FaEnvelope className="mx-auto text-[#a27c45]" />

              <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9b9287]">
                Email
              </p>

              <p className="mt-1 truncate text-sm font-medium">
                {email}
              </p>
            </button>
          )}

          {website && (
            <button
              type="button"
              onClick={() => handleContact("website")}
              className="group border-b border-[#e7dfd2] p-6 text-center transition hover:bg-[#f8f5ef] sm:border-r sm:border-b-0"
            >
              <FaGlobe className="mx-auto text-[#a27c45]" />

              <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9b9287]">
                Website
              </p>

              <p className="mt-1 truncate text-sm font-medium">
                {website}
              </p>
            </button>
          )}

          {(address || location) && (
            <button
              type="button"
              onClick={() => handleContact("address")}
              className="group p-6 text-center transition hover:bg-[#f8f5ef]"
            >
              <FaLocationDot className="mx-auto text-[#a27c45]" />

              <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9b9287]">
                Location
              </p>

              <p className="mt-1 line-clamp-2 text-sm font-medium">
                {address || location}
              </p>
            </button>
          )}
        </div>
      </section>

      {/* =====================================================
          QUICK LINKS
      ===================================================== */}
      {visibleButtons.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
          <div className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
              Explore
            </p>

            <h2 className="mt-3 font-serif text-4xl">
              Services & Links
            </h2>

            <div className="mx-auto mt-5 h-px w-16 bg-[#a27c45]" />
          </div>

          <div className="mx-auto mt-10 max-w-3xl space-y-3">
            {visibleButtons.map((button, index) => (
              <button
                key={button._id || button.id || index}
                type="button"
                onClick={() => onConfiguredButton(button)}
                className="group flex w-full items-center justify-between border-b border-[#ddd3c5] bg-white/50 px-5 py-5 text-left transition hover:bg-white"
              >
                <span className="font-serif text-lg">
                  {button.label || "Service"}
                </span>

                <span className="flex h-9 w-9 items-center justify-center rounded-full border border-[#d9cdbb] text-[#a27c45] transition group-hover:bg-[#29251f] group-hover:text-white">
                  <FaArrowRight />
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* =====================================================
          ABOUT
      ===================================================== */}
      {about && (
        <section className="bg-[#29251f] text-white">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
            <div className="grid gap-10 lg:grid-cols-[0.65fr_1.35fr]">
              <div>
                <p className="text-xs uppercase tracking-[0.3em] text-[#c9a66c]">
                  About
                </p>

                <h2 className="mt-4 font-serif text-4xl leading-tight sm:text-5xl">
                  A little more about me.
                </h2>
              </div>

              <div className="border-l border-white/10 pl-6 lg:pl-10">
                <p className="text-sm leading-8 text-white/65 sm:text-base">
                  {about}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          PRODUCTS
      ===================================================== */}
      {productList.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
          <div className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
              Collection
            </p>

            <h2 className="mt-3 font-serif text-4xl">
              Featured Work
            </h2>

            <div className="mx-auto mt-5 h-px w-16 bg-[#a27c45]" />
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {productList.map((product, index) => {
              const image = getProductImage(product);

              return (
                <button
                  key={product._id || product.id || index}
                  type="button"
                  onClick={() => onProductClick(product)}
                  className="group overflow-hidden border border-[#e0d7ca] bg-white text-left transition hover:-translate-y-1 hover:shadow-xl"
                >
                  <div className="relative h-72 overflow-hidden bg-[#eee9e1]">
                    {image ? (
                      <img
                        src={image}
                        alt={product.name || "Product"}
                        className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-sm text-[#989087]">
                        No Image
                      </div>
                    )}

                    <div className="absolute bottom-4 left-4 rounded-full bg-white/90 px-4 py-2 text-xs font-semibold text-[#4c453c]">
                      View Details
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="font-serif text-xl font-semibold">
                        {product.name || "Product"}
                      </h3>

                      {product.price !== undefined &&
                        product.price !== null &&
                        product.price !== "" && (
                          <span className="whitespace-nowrap text-sm font-semibold text-[#a27c45]">
                            ₹{product.price}
                          </span>
                        )}
                    </div>

                    {product.description && (
                      <p className="mt-3 line-clamp-2 text-sm leading-6 text-[#7c746a]">
                        {product.description}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* =====================================================
          GALLERY
      ===================================================== */}
      {galleryImages.length > 0 && (
        <section className="bg-white">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
            <div className="text-center">
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
                Gallery
              </p>

              <h2 className="mt-3 font-serif text-4xl">
                Moments & Memories
              </h2>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {galleryImages.map((image, index) => {
                const imageUrl = getImageUrl(image);

                return (
                  <button
                    key={image._id || image.id || index}
                    type="button"
                    onClick={() => onGalleryClick(image)}
                    className="group relative aspect-square overflow-hidden"
                  >
                    {imageUrl && (
                      <img
                        src={imageUrl}
                        alt={image.alt || "Gallery"}
                        className="h-full w-full object-cover grayscale-[15%] transition duration-700 group-hover:scale-110 group-hover:grayscale-0"
                      />
                    )}

                    <div className="absolute inset-0 bg-[#29251f]/0 transition group-hover:bg-[#29251f]/20" />
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          BUSINESS HOURS
      ===================================================== */}
      {businessHours && (
        <section className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <FaClock className="mx-auto text-[#a27c45]" />

            <p className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
              Availability
            </p>

            <h2 className="mt-3 font-serif text-3xl">
              Working Hours
            </h2>

            <p className="mt-4 whitespace-pre-line text-sm leading-7 text-[#766e64]">
              {businessHours}
            </p>
          </div>
        </section>
      )}

      {/* =====================================================
          SOCIAL
      ===================================================== */}
      {socialLinks.length > 0 && (
        <section className="border-y border-[#e7dfd2] bg-[#f1ece4]">
          <div className="mx-auto max-w-6xl px-5 py-14 text-center sm:px-8">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
              Social
            </p>

            <h2 className="mt-3 font-serif text-3xl">
              Connect With Me
            </h2>

            <div className="mt-7 flex flex-wrap justify-center gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={social._id || social.id || index}
                  href={social.url || "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="flex h-12 w-12 items-center justify-center rounded-full border border-[#d8cdbd] bg-white text-[#514a41] transition hover:bg-[#29251f] hover:text-white"
                  title={social.platform || "Social"}
                >
                  {getSocialIcon(social.platform)}
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          QR
      ===================================================== */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-[#29251f] px-7 py-10 text-white sm:px-10">
          <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full border border-white/5" />
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full border border-white/5" />

          <div className="relative grid items-center gap-8 lg:grid-cols-[1fr_auto]">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-[#c9a66c]">
                Digital Card
              </p>

              <h2 className="mt-3 font-serif text-4xl">
                Share My Profile
              </h2>

              <p className="mt-4 max-w-xl text-sm leading-7 text-white/60">
                Scan the QR code to open this profile instantly or share it
                with your network.
              </p>

              <button
                type="button"
                onClick={onOpenQr}
                className="mt-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3 text-sm font-semibold transition hover:bg-white hover:text-[#29251f]"
              >
                <FaQrcode />
                Open QR
              </button>
            </div>

            <div className="flex justify-center">
              <div className="rounded-3xl bg-white p-4">
                {qrFetching ? (
                  <div className="flex h-40 w-40 items-center justify-center text-xs text-slate-400">
                    Loading...
                  </div>
                ) : qrTargetUrl ? (
                  <QRCodeCanvas
                    value={qrTargetUrl}
                    size={160}
                    includeMargin
                  />
                ) : (
                  <div className="flex h-40 w-40 items-center justify-center text-center text-xs text-slate-400">
                    QR unavailable
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT FORM
      ===================================================== */}
      <section className="border-t border-[#e7dfd2] bg-white">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.75fr_1.25fr]">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[#a27c45]">
                Get In Touch
              </p>

              <h2 className="mt-4 font-serif text-4xl leading-tight sm:text-5xl">
                Let's start a conversation.
              </h2>

              <p className="mt-5 text-sm leading-8 text-[#766e64]">
                Have a question, project or business opportunity? Send a
                message and let's connect.
              </p>
            </div>

            <form
              onSubmit={onFormSubmit}
              className="border border-[#dfd6c9] bg-[#f8f5ef] p-6 sm:p-8"
            >
              {formSubmitted ? (
                <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#a27c45] text-white">
                    <FaCheck />
                  </div>

                  <h3 className="mt-5 font-serif text-2xl">
                    Thank You
                  </h3>

                  <p className="mt-2 text-sm text-[#766e64]">
                    Your inquiry has been submitted successfully.
                  </p>
                </div>
              ) : (
                <>
                  {inquirySubmitError && (
                    <div className="mb-5 border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
                      {inquirySubmitError}
                    </div>
                  )}

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-[#81786d]">
                        Name
                      </label>

                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="Your name"
                        className="w-full border border-[#dcd2c4] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#a27c45]"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-[#81786d]">
                        Phone
                      </label>

                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            phone: e.target.value,
                          }))
                        }
                        placeholder="Phone number"
                        className="w-full border border-[#dcd2c4] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#a27c45]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-[#81786d]">
                        Email
                      </label>

                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            email: e.target.value,
                          }))
                        }
                        placeholder="Email address"
                        className="w-full border border-[#dcd2c4] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#a27c45]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-[#81786d]">
                        Message
                      </label>

                      <textarea
                        rows={5}
                        value={formData.message}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            message: e.target.value,
                          }))
                        }
                        placeholder="Write your message..."
                        className="w-full resize-none border border-[#dcd2c4] bg-white px-4 py-3 text-sm outline-none transition focus:border-[#a27c45]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={inquirySubmitting}
                    className="mt-6 w-full rounded-full bg-[#29251f] px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#a27c45] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {inquirySubmitting ? "Sending..." : "Send Message"}
                  </button>
                </>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* =====================================================
          FOOTER
      ===================================================== */}
      <footer className="bg-[#29251f] text-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 text-center sm:flex-row sm:px-8 sm:text-left">
          <div>
            <p className="font-serif text-lg">{displayName}</p>

            <p className="mt-1 text-xs text-white/40">
              {industry || displayRole}
            </p>
          </div>

          <p className="text-xs text-white/40">
            Digital Business Profile
          </p>
        </div>
      </footer>
    </div>
  );
};

export default ElegantProfile;