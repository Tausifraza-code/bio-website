import React from "react";
import { QRCodeCanvas } from "qrcode.react";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaXTwitter,
  FaYoutube,
  FaGlobe,
  FaPhone,
  FaWhatsapp,
  FaEnvelope,
  FaLocationDot,
  FaShareNodes,
  FaQrcode,
  FaArrowUpRightFromSquare,
  FaClock,
  FaCheck,
} from "react-icons/fa6";

const CorporateExecutive = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],
  qrTargetUrl = "",
  qrFetching = false,
  formData = { name: "", phone: "", email: "", message: "" },
  setFormData = () => {},
  onFormSubmit = () => {},
  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,
  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "Your Name",
    role = "Business Professional",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = "",
    avatar = "",
    banner = "",
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const displayName = name || businessName || "Your Name";
  const displayRole = role || industry || "Business Professional";

  const getSocialIcon = (platform) => {
    const value = String(platform || "").toLowerCase();

    if (value.includes("facebook")) return <FaFacebookF />;
    if (value.includes("instagram")) return <FaInstagram />;
    if (value.includes("linkedin")) return <FaLinkedinIn />;
    if (value.includes("twitter") || value.includes("x.com"))
      return <FaXTwitter />;
    if (value.includes("youtube")) return <FaYoutube />;

    return <FaGlobe />;
  };

  const getImageUrl = (image) => {
    if (!image) return "";

    if (typeof image === "string") return image;

    return image.url || image.imageUrl || image.src || "";
  };

  const heroImage = getImageUrl(banner);
  const profileImage = getImageUrl(avatar || logo);

  const handleContact = (type) => {
    onContactClick(type);
  };

  return (
    <div className="min-h-screen bg-[#f4f7fb] text-[#14213d]">
      {/* =========================================================
          TOP NAV / BRAND BAR
      ========================================================= */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            {logo ? (
              <img
                src={getImageUrl(logo)}
                alt={displayName}
                className="h-11 w-11 rounded-xl border border-slate-200 object-cover"
              />
            ) : (
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#14213d] text-lg font-bold text-white">
                {displayName.charAt(0).toUpperCase()}
              </div>
            )}

            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-[#14213d]">
                {businessName || displayName}
              </p>

              <p className="truncate text-xs text-slate-500">
                {industry || displayRole}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onShare}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#14213d] hover:bg-[#14213d] hover:text-white"
              title="Share"
            >
              <FaShareNodes />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-[#14213d] hover:bg-[#14213d] hover:text-white"
              title="QR Code"
            >
              <FaQrcode />
            </button>
          </div>
        </div>
      </header>

      {/* =========================================================
          HERO
      ========================================================= */}
      <section className="relative overflow-hidden bg-[#14213d]">
        {heroImage && (
          <div className="absolute inset-0">
            <img
              src={heroImage}
              alt=""
              className="h-full w-full object-cover opacity-20"
            />

            <div className="absolute inset-0 bg-[#14213d]/85" />
          </div>
        )}

        {!heroImage && (
          <div className="absolute -right-32 -top-32 h-80 w-80 rounded-full bg-[#00c2ff]/20 blur-3xl" />
        )}

        <div className="relative mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:py-20">
          <div className="grid items-center gap-12 lg:grid-cols-[1.4fr_0.6fr]">
            {/* LEFT */}
            <div>
              <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/80">
                <span className="h-2 w-2 rounded-full bg-[#00c2ff]" />
                Professional Profile
              </div>

              <h1 className="max-w-3xl text-4xl font-black leading-tight text-white sm:text-5xl lg:text-6xl">
                {displayName}
              </h1>

              <p className="mt-4 text-lg font-medium text-[#00c2ff] sm:text-xl">
                {displayRole}
              </p>

              {location && (
                <div className="mt-4 flex items-center gap-2 text-sm text-white/70">
                  <FaLocationDot />
                  <span>{location}</span>
                </div>
              )}

              {about && (
                <p className="mt-7 max-w-2xl text-sm leading-7 text-white/75 sm:text-base">
                  {about}
                </p>
              )}

              {/* HERO ACTIONS */}
              <div className="mt-8 flex flex-wrap gap-3">
                {phone && (
                  <button
                    type="button"
                    onClick={() => handleContact("phone")}
                    className="inline-flex items-center gap-2 rounded-xl bg-[#00c2ff] px-5 py-3 text-sm font-bold text-[#08213d] transition hover:-translate-y-0.5 hover:bg-white"
                  >
                    <FaPhone />
                    Call Now
                  </button>
                )}

                {whatsapp && (
                  <button
                    type="button"
                    onClick={() => handleContact("whatsapp")}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-white hover:text-[#14213d]"
                  >
                    <FaWhatsapp />
                    WhatsApp
                  </button>
                )}
              </div>
            </div>

            {/* PROFILE CARD */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative w-full max-w-sm rounded-3xl border border-white/10 bg-white/10 p-4 shadow-2xl backdrop-blur-md">
                <div className="overflow-hidden rounded-2xl bg-white">
                  {profileImage ? (
                    <img
                      src={profileImage}
                      alt={displayName}
                      className="h-80 w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-80 items-center justify-center bg-slate-100 text-7xl font-black text-[#14213d]">
                      {displayName.charAt(0).toUpperCase()}
                    </div>
                  )}

                  <div className="p-5">
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-bold text-[#14213d]">
                        {displayName}
                      </h2>

                      {isVerified && (
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#00c2ff] text-[10px] text-[#14213d]">
                          <FaCheck />
                        </span>
                      )}
                    </div>

                    <p className="mt-1 text-sm text-slate-500">
                      {displayRole}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          QUICK CONTACT
      ========================================================= */}
      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {phone && (
            <button
              type="button"
              onClick={() => handleContact("phone")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#00c2ff]"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-[#14213d] transition group-hover:bg-[#14213d] group-hover:text-white">
                <FaPhone />
              </div>

              <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Phone
              </p>

              <p className="mt-1 truncate text-sm font-bold text-[#14213d]">
                {phone}
              </p>
            </button>
          )}

          {email && (
            <button
              type="button"
              onClick={() => handleContact("email")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#00c2ff]"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-[#14213d] transition group-hover:bg-[#14213d] group-hover:text-white">
                <FaEnvelope />
              </div>

              <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Email
              </p>

              <p className="mt-1 truncate text-sm font-bold text-[#14213d]">
                {email}
              </p>
            </button>
          )}

          {website && (
            <button
              type="button"
              onClick={() => handleContact("website")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#00c2ff]"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-[#14213d] transition group-hover:bg-[#14213d] group-hover:text-white">
                <FaGlobe />
              </div>

              <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Website
              </p>

              <p className="mt-1 truncate text-sm font-bold text-[#14213d]">
                {website}
              </p>
            </button>
          )}

          {(address || location) && (
            <button
              type="button"
              onClick={() => handleContact("address")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#00c2ff]"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-[#14213d] transition group-hover:bg-[#14213d] group-hover:text-white">
                <FaLocationDot />
              </div>

              <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Location
              </p>

              <p className="mt-1 line-clamp-2 text-sm font-bold text-[#14213d]">
                {address || location}
              </p>
            </button>
          )}
        </div>
      </section>

      {/* =========================================================
          CONFIGURED CONTACT BUTTONS
      ========================================================= */}
      {visibleButtons.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-10 sm:px-8">
          <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="mb-5">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
                Quick Actions
              </p>

              <h2 className="mt-1 text-2xl font-black text-[#14213d]">
                Connect With Me
              </h2>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {visibleButtons.map((button, index) => (
                <button
                  key={button._id || button.id || index}
                  type="button"
                  onClick={() => onConfiguredButton(button)}
                  className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-4 text-left transition hover:border-[#00c2ff] hover:bg-slate-50"
                >
                  <span className="font-semibold text-[#14213d]">
                    {button.label || "Contact"}
                  </span>

                  <FaArrowUpRightFromSquare className="text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* =========================================================
          ABOUT
      ========================================================= */}
      {about && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
                About
              </p>

              <h2 className="mt-2 text-3xl font-black text-[#14213d]">
                Professional & Reliable
              </h2>
            </div>

            <div className="rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
              <p className="text-sm leading-8 text-slate-600">
                {about}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* =========================================================
          BUSINESS HOURS
      ========================================================= */}
      {businessHours && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="rounded-3xl bg-[#14213d] p-7 text-white">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/10 text-[#00c2ff]">
                <FaClock />
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00c2ff]">
                  Business Hours
                </p>

                <p className="mt-2 whitespace-pre-line text-sm leading-7 text-white/75">
                  {businessHours}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =========================================================
          SOCIAL LINKS
      ========================================================= */}
      {socialLinks.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
              Social Media
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#14213d]">
              Follow & Connect
            </h2>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={social._id || social.id || index}
                  href={social.url || "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 bg-white text-[#14213d] shadow-sm transition hover:-translate-y-1 hover:bg-[#14213d] hover:text-white"
                  title={social.platform || "Social"}
                >
                  {getSocialIcon(social.platform)}
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* =========================================================
          PRODUCTS
      ========================================================= */}
      {productList.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="mb-7">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
              Products
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#14213d]">
              Featured Products
            </h2>
          </div>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {productList.map((product, index) => {
              const image = getImageUrl(
                product?.images?.[0] || product?.image
              );

              return (
                <button
                  type="button"
                  key={product._id || product.id || index}
                  onClick={() => onProductClick(product)}
                  className="overflow-hidden rounded-3xl border border-slate-200 bg-white text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
                >
                  <div className="h-56 overflow-hidden bg-slate-100">
                    {image ? (
                      <img
                        src={image}
                        alt={product.name || "Product"}
                        className="h-full w-full object-cover transition duration-500 hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-sm font-semibold text-slate-400">
                        No Image
                      </div>
                    )}
                  </div>

                  <div className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="font-bold text-[#14213d]">
                        {product.name || "Product"}
                      </h3>

                      {product.price !== undefined &&
                        product.price !== null &&
                        product.price !== "" && (
                          <span className="whitespace-nowrap text-sm font-black text-[#00a8df]">
                            ₹{product.price}
                          </span>
                        )}
                    </div>

                    {product.description && (
                      <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-500">
                        {product.description}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* =========================================================
          GALLERY
      ========================================================= */}
      {galleryImages.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="mb-7">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
              Gallery
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#14213d]">
              Our Work
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {galleryImages.map((image, index) => {
              const imageUrl = getImageUrl(image);

              return (
                <button
                  type="button"
                  key={image._id || image.id || index}
                  onClick={() => onGalleryClick(image)}
                  className="group relative aspect-square overflow-hidden rounded-2xl bg-slate-100"
                >
                  {imageUrl && (
                    <img
                      src={imageUrl}
                      alt={image.alt || "Gallery"}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                    />
                  )}

                  <div className="absolute inset-0 bg-[#14213d]/0 transition group-hover:bg-[#14213d]/30" />
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* =========================================================
          QR SECTION
      ========================================================= */}
      <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
        <div className="overflow-hidden rounded-3xl bg-[#14213d]">
          <div className="grid items-center gap-8 p-7 sm:p-10 lg:grid-cols-[1fr_auto]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00c2ff]">
                Digital Business Card
              </p>

              <h2 className="mt-2 text-3xl font-black text-white">
                Share My Profile
              </h2>

              <p className="mt-3 max-w-xl text-sm leading-7 text-white/65">
                Scan the QR code to instantly open this digital profile and
                connect with the business.
              </p>

              <button
                type="button"
                onClick={onOpenQr}
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#00c2ff] px-5 py-3 text-sm font-bold text-[#14213d] transition hover:bg-white"
              >
                <FaQrcode />
                Open QR
              </button>
            </div>

            <div className="flex justify-center">
              <div className="rounded-3xl bg-white p-4">
                {qrFetching ? (
                  <div className="flex h-40 w-40 items-center justify-center text-xs font-semibold text-slate-400">
                    Loading...
                  </div>
                ) : qrTargetUrl ? (
                  <QRCodeCanvas
                    value={qrTargetUrl}
                    size={160}
                    includeMargin
                  />
                ) : (
                  <div className="flex h-40 w-40 items-center justify-center text-center text-xs font-semibold text-slate-400">
                    QR unavailable
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          INQUIRY FORM
      ========================================================= */}
      <section className="mx-auto max-w-7xl px-5 pb-16 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-[0.75fr_1.25fr]">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#00a8df]">
              Contact
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#14213d]">
              Send an Inquiry
            </h2>

            <p className="mt-4 text-sm leading-7 text-slate-500">
              Have a question or want to discuss a business opportunity?
              Send a message and get in touch.
            </p>
          </div>

          <form
            onSubmit={onFormSubmit}
            className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8"
          >
            {formSubmitted ? (
              <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#00c2ff]/15 text-2xl text-[#008db8]">
                  <FaCheck />
                </div>

                <h3 className="mt-5 text-xl font-black text-[#14213d]">
                  Message Sent
                </h3>

                <p className="mt-2 text-sm text-slate-500">
                  Thank you. Your inquiry has been submitted successfully.
                </p>
              </div>
            ) : (
              <>
                {inquirySubmitError && (
                  <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
                    {inquirySubmitError}
                  </div>
                )}

                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                      Name
                    </label>

                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          name: e.target.value,
                        }))
                      }
                      placeholder="Your name"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-[#00c2ff] focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                      Phone
                    </label>

                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          phone: e.target.value,
                        }))
                      }
                      placeholder="Phone number"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-[#00c2ff] focus:bg-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                      Email
                    </label>

                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          email: e.target.value,
                        }))
                      }
                      placeholder="Email address"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-[#00c2ff] focus:bg-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                      Message
                    </label>

                    <textarea
                      rows={5}
                      value={formData.message}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          message: e.target.value,
                        }))
                      }
                      placeholder="Write your message..."
                      className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-[#00c2ff] focus:bg-white"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={inquirySubmitting}
                  className="mt-6 flex w-full items-center justify-center rounded-xl bg-[#14213d] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#00a8df] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {inquirySubmitting ? "Sending..." : "Send Inquiry"}
                </button>
              </>
            )}
          </form>
        </div>
      </section>

      {/* =========================================================
          FOOTER
      ========================================================= */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-5 py-7 text-center sm:flex-row sm:px-8 sm:text-left">
          <div>
            <p className="font-bold text-[#14213d]">{displayName}</p>
            <p className="mt-1 text-xs text-slate-400">
              {businessName || industry || "Digital Business Profile"}
            </p>
          </div>

          <p className="text-xs text-slate-400">
            Powered by Digital Business Card
          </p>
        </div>
      </footer>
    </div>
  );
};

export default CorporateExecutive;