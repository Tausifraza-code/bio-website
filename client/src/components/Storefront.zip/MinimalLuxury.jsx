
import React from "react";
import { QRCodeCanvas } from "qrcode.react";

import {
  MapPin,
  Phone,
  Mail,
  Globe,
  MessageCircle,
  Share2,
  UserRound,
  CheckCircle2,
  Clock,
  Download,
  Image as ImageIcon,
  ArrowUpRight,
  BriefcaseBusiness,
  Code2,
  Palette,
  Headset,
  ScanLine,
  Send,
  ExternalLink,
  ShoppingBag,
} from "lucide-react";

import {
  FaInstagram,
  FaLinkedinIn,
  FaFacebookF,
  FaYoutube,
  FaWhatsapp,
  FaTelegram,
  FaXTwitter,
  FaLink,
} from "react-icons/fa6";

// ============================================
// MINIMAL LUXURY LAYOUT
// Clean White + Warm Beige + Luxury Black
// Responsive: Mobile, Tablet and Desktop
// ============================================

const MinimalLuxury = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],

  qrTargetUrl = "",
  qrFetching = false,

  formData = {
    name: "",
    phone: "",
    email: "",
    message: "",
  },

  setFormData = () => {},
  onFormSubmit = () => {},

  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,

  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "",
    role = "",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = null,
    avatar = null,
    banner = null,
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const socialIconMap = {
    instagram: FaInstagram,
    linkedin: FaLinkedinIn,
    facebook: FaFacebookF,
    youtube: FaYoutube,
    whatsapp: FaWhatsapp,
    telegram: FaTelegram,
    twitter: FaXTwitter,
  };

  const getSocialIcon = (platform = "") => {
    const key = platform.toLowerCase();

    const found = Object.keys(socialIconMap).find((item) =>
      key.includes(item)
    );

    return found ? socialIconMap[found] : FaLink;
  };

  const normalizeUrl = (url = "") => {
    if (!url) return "#";

    return /^https?:\/\//i.test(url)
      ? url
      : `https://${url}`;
  };

  const services = [
    {
      title: "Web Development",
      description: "Modern websites and web applications",
      icon: Code2,
    },
    {
      title: "UI/UX Design",
      description: "Beautiful and user-friendly interfaces",
      icon: Palette,
    },
    {
      title: "Branding",
      description: "Build a memorable brand identity",
      icon: BriefcaseBusiness,
    },
    {
      title: "Consultation",
      description: "Professional business guidance",
      icon: Headset,
    },
  ];

  const sectionClass =
    "rounded-2xl border border-[#EAE6DF] bg-white p-5 sm:p-7";

  const headingClass =
    "text-xl font-bold tracking-tight text-[#202020] sm:text-2xl";

  const inputClass =
    "w-full rounded-xl border border-[#E7E2D9] bg-[#FAF9F6] px-4 py-3.5 text-sm text-[#252525] placeholder:text-[#A09B91] outline-none transition focus:border-[#A58A62] focus:ring-2 focus:ring-[#A58A62]/10 disabled:opacity-50";

  return (
    <div className="minimal-luxury w-full overflow-hidden rounded-[20px] border border-[#E9E4DB] bg-[#FAF9F6] text-[#242424] shadow-xl shadow-black/5 sm:rounded-[26px]">

      {/* ================================== */}
      {/* NAVBAR */}
      {/* ================================== */}

      <header className="relative z-10 border-b border-[#EEEAE3] bg-white px-5 py-4 sm:px-8 lg:px-10">

        <div className="flex items-center justify-between gap-4">

          <div className="flex min-w-0 items-center gap-2.5">

            {logo ? (
              <img
                src={logo}
                alt="Business logo"
                className="h-9 w-9 rounded-lg border border-[#EEEAE3] bg-white object-contain p-1"
              />
            ) : (
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#252525] text-white">
                <span className="text-lg font-black">B</span>
              </div>
            )}

            <span className="text-xl font-black tracking-tight text-[#222222]">
              Bio<span className="text-[#A58A62]">.</span>
            </span>

          </div>

          <nav className="hidden items-center gap-5 lg:flex">

            {[
              ["Home", "#minimal-home"],
              ["About", "#minimal-about"],
              ["Products", "#minimal-products"],
              ["Gallery", "#minimal-gallery"],
              ["Contact", "#minimal-contact"],
            ].map(([label, href]) => (
              <a
                key={label}
                href={href}
                className="text-xs font-semibold text-[#55514B] transition hover:text-[#A58A62]"
              >
                {label}
              </a>
            ))}

          </nav>

          <div className="flex shrink-0 items-center gap-2">

            <button
              type="button"
              onClick={onShare}
              aria-label="Share profile"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#EAE6DF] text-[#55514B] transition hover:border-[#A58A62] hover:text-[#A58A62]"
            >
              <Share2 size={16} />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex items-center gap-1.5 rounded-lg bg-[#252525] px-3.5 py-2.5 text-xs font-bold text-white transition hover:bg-[#A58A62]"
            >
              <ScanLine size={14} />
              <span>Contact</span>
            </button>

          </div>

        </div>

      </header>

      {/* ================================== */}
      {/* HERO SECTION */}
      {/* ================================== */}

      <section
        id="minimal-home"
        className="relative overflow-hidden bg-white px-5 py-9 sm:px-8 sm:py-14 lg:px-10 lg:py-16"
      >

        <div className="grid items-center gap-8 md:grid-cols-12 md:gap-10">

          {/* HERO CONTENT */}

          <div className="order-2 md:order-1 md:col-span-7">

            <p className="text-xs font-semibold tracking-wide text-[#8B8173]">
              Hello, I'm
            </p>

            <div className="mt-2 flex flex-wrap items-center gap-2">

              <h1 className="text-3xl font-black leading-tight tracking-tight text-[#222222] sm:text-4xl lg:text-[42px]">
                {name || "Your Name"}
              </h1>

              {isVerified && (
                <CheckCircle2
                  size={22}
                  className="fill-[#A58A62] text-white"
                  title="Verified Profile"
                />
              )}

            </div>

            <p className="mt-2 text-base font-semibold text-[#55514B] sm:text-lg">
              {role || "Web Developer & Designer"}
            </p>

            <p className="mt-4 max-w-xl text-sm leading-7 text-[#858078]">
              {about ||
                "I create beautiful digital experiences and modern solutions for businesses. Let's work together to bring your ideas to life."}
            </p>

            {location && (
              <p className="mt-4 flex items-center gap-2 text-xs font-medium text-[#8B8173]">
                <MapPin size={15} className="text-[#A58A62]" />
                {location}
              </p>
            )}

            <div className="mt-6 flex flex-wrap gap-3">

              {visibleButtons.length > 0 ? (
                visibleButtons.map((button, index) => (
                  <button
                    key={button._id || button.id || index}
                    type="button"
                    onClick={() => onConfiguredButton(button)}
                    className={`flex items-center gap-2 rounded-full px-5 py-3 text-xs font-bold transition sm:text-sm ${
                      button.actionType === "whatsapp"
                        ? "bg-[#239B69] text-white hover:bg-[#198557]"
                        : button.actionType === "call"
                          ? "bg-[#252525] text-white hover:bg-[#A58A62]"
                          : "border border-[#DDD6CA] bg-white text-[#333333] hover:border-[#A58A62] hover:text-[#A58A62]"
                    }`}
                  >
                    {button.label}
                    <ArrowUpRight size={14} />
                  </button>
                ))
              ) : (
                <>
                  {phone && (
                    <button
                      type="button"
                      onClick={() => onContactClick("phone")}
                      className="flex items-center gap-2 rounded-full bg-[#252525] px-5 py-3 text-xs font-bold text-white transition hover:bg-[#A58A62] sm:text-sm"
                    >
                      <Phone size={15} />
                      Get in Touch
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={onShare}
                    className="flex items-center gap-2 rounded-full border border-[#DDD6CA] bg-white px-5 py-3 text-xs font-bold text-[#333333] transition hover:border-[#A58A62] hover:text-[#A58A62] sm:text-sm"
                  >
                    <Share2 size={15} />
                    View Portfolio
                  </button>
                </>
              )}

            </div>

            {socialLinks.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">

                {socialLinks.map((social, index) => {
                  const Icon = getSocialIcon(social.platform);

                  return (
                    <a
                      key={social._id || `${social.platform}-${index}`}
                      href={normalizeUrl(social.url)}
                      target="_blank"
                      rel="noopener noreferrer"
                      title={social.platform}
                      className="flex h-9 w-9 items-center justify-center rounded-full border border-[#EAE6DF] bg-[#FAF9F6] text-[#686158] transition hover:border-[#A58A62] hover:bg-[#A58A62] hover:text-white"
                    >
                      <Icon size={15} />
                    </a>
                  );
                })}

              </div>
            )}

          </div>

          {/* HERO IMAGE */}

          <div className="order-1 md:order-2 md:col-span-5">

            <div className="relative mx-auto max-w-[310px] md:ml-auto md:mr-0">

              <div className="absolute -right-3 -top-3 h-24 w-24 rounded-2xl bg-[#F0EBE2] sm:-right-4 sm:-top-4 sm:h-32 sm:w-32" />

              <div className="relative aspect-[4/4.5] overflow-hidden rounded-2xl bg-[#EDE8DF]">

                {avatar ? (
                  <img
                    src={avatar}
                    alt={name || "Profile"}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <UserRound size={75} className="text-[#B7AA96]" />
                  </div>
                )}

              </div>

              <div className="absolute -bottom-3 -left-3 rounded-xl border border-[#EAE6DF] bg-white px-4 py-3 shadow-lg sm:-bottom-4 sm:-left-4">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#A58A62]">
                  Welcome to
                </p>
                <p className="mt-1 text-sm font-bold text-[#252525]">
                  {businessName || "My Business"}
                </p>
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* STATS */}
      {/* ================================== */}

      <section className="border-y border-[#EAE6DF] bg-[#F5F2EC] px-5 py-6 sm:px-8 lg:px-10">

        <div className="grid grid-cols-3 gap-3">

          {[
            {
              value: "2+",
              label: "Years Experience",
              icon: BriefcaseBusiness,
            },
            {
              value: `${productList.length}+`,
              label: "Products",
              icon: ShoppingBag,
            },
            {
              value: "100%",
              label: "Client Satisfaction",
              icon: CheckCircle2,
            },
          ].map((item, index) => (
            <div
              key={item.label}
              className={`flex flex-col items-center justify-center gap-2 text-center sm:flex-row sm:gap-3 ${
                index !== 2 ? "border-r border-[#DDD6CA]" : ""
              }`}
            >

              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-[#A58A62]">
                <item.icon size={17} />
              </div>

              <div>
                <h3 className="text-lg font-black text-[#252525] sm:text-xl">
                  {item.value}
                </h3>

                <p className="text-[9px] font-medium text-[#898176] sm:text-xs">
                  {item.label}
                </p>
              </div>

            </div>
          ))}

        </div>

      </section>

      {/* ================================== */}
      {/* ABOUT ME */}
      {/* ================================== */}

      <section
        id="minimal-about"
        className="px-5 py-9 sm:px-8 sm:py-12 lg:px-10"
      >

        <div className="grid items-center gap-7 md:grid-cols-12 md:gap-10">

          <div className="md:col-span-7">

            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
              A little introduction
            </p>

            <h2 className="mt-2 text-2xl font-black tracking-tight text-[#252525] sm:text-3xl">
              About Me
            </h2>

            <p className="mt-4 text-sm leading-7 text-[#777168]">
              {about ||
                "I'm a passionate professional who loves creating meaningful work and delivering quality solutions. My focus is on combining creativity, innovation and functionality."}
            </p>

            <div className="mt-5 space-y-3">

              {[
                "Web Development",
                "UI/UX Design",
                "Creative Solutions",
                "Problem Solving",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-3 text-sm font-medium text-[#5C574F]"
                >
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#F0EBE2] text-[#A58A62]">
                    <CheckCircle2 size={14} />
                  </span>
                  {item}
                </div>
              ))}

            </div>

            {industry && (
              <span className="mt-5 inline-flex rounded-full bg-[#F0EBE2] px-4 py-2 text-xs font-semibold text-[#8D7656]">
                {industry}
              </span>
            )}

          </div>

          <div className="md:col-span-5">

            <div className="relative overflow-hidden rounded-2xl bg-[#EDE8DF]">

              {banner ? (
                <img
                  src={banner}
                  alt="About"
                  loading="lazy"
                  className="h-56 w-full object-cover sm:h-64"
                />
              ) : (
                <div className="flex h-56 items-center justify-center sm:h-64">
                  <BriefcaseBusiness
                    size={55}
                    className="text-[#B7AA96]"
                  />
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />

            </div>

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* SERVICES */}
      {/* ================================== */}

      <section className="bg-white px-5 py-9 sm:px-8 sm:py-12 lg:px-10">

        <div className="mb-6 flex items-end justify-between gap-3">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
              What I offer
            </p>

            <h2 className="mt-2 text-2xl font-black text-[#252525]">
              My Services
            </h2>
          </div>

          <ArrowUpRight size={22} className="text-[#A58A62]" />

        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">

          {services.map((service) => (
            <div
              key={service.title}
              className="group rounded-xl border border-[#EEEAE3] bg-[#FAF9F6] p-4 transition duration-300 hover:-translate-y-1 hover:border-[#C8B79D] hover:bg-white sm:p-5"
            >

              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-[#F0EBE2] text-[#A58A62] transition group-hover:bg-[#252525] group-hover:text-white">
                <service.icon size={19} />
              </div>

              <h3 className="text-xs font-bold leading-5 text-[#333333] sm:text-sm">
                {service.title}
              </h3>

              <p className="mt-2 text-[10px] leading-5 text-[#918A80]">
                {service.description}
              </p>

            </div>
          ))}

        </div>

      </section>

      {/* ================================== */}
      {/* FEATURED PRODUCTS */}
      {/* ================================== */}

      {productList.length > 0 && (
        <section
          id="minimal-products"
          className="px-5 py-9 sm:px-8 sm:py-12 lg:px-10"
        >

          <div className="mb-6 flex items-end justify-between gap-3">

            <div>
              <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
                Handpicked collection
              </p>

              <h2 className="mt-2 text-2xl font-black text-[#252525]">
                Featured Products
              </h2>
            </div>

            <span className="text-xs font-semibold text-[#8D857A]">
              {productList.length} Items
            </span>

          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">

            {productList.map((product) => {
              const cover = product.images?.find(
                (item) => item?.url
              )?.url;

              return (
                <button
                  key={product._id}
                  type="button"
                  onClick={() => onProductClick(product)}
                  className="group overflow-hidden rounded-xl border border-[#EAE6DF] bg-white text-left transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/5"
                >

                  <div className="relative h-48 overflow-hidden bg-[#F0EBE2]">

                    {cover ? (
                      <img
                        src={cover}
                        alt={product.name}
                        loading="lazy"
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center">
                        <ImageIcon
                          size={35}
                          className="text-[#B7AA96]"
                        />
                      </div>
                    )}

                    <span className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white text-[#252525] shadow-sm transition group-hover:bg-[#252525] group-hover:text-white">
                      <ArrowUpRight size={17} />
                    </span>

                  </div>

                  <div className="p-4">

                    <h3 className="truncate text-sm font-bold text-[#292929]">
                      {product.name}
                    </h3>

                    <p className="mt-2 line-clamp-2 text-xs leading-5 text-[#8B847A]">
                      {product.description}
                    </p>

                    <div className="mt-4 flex items-center justify-between">

                      <p className="text-base font-black text-[#252525]">
                        ₹{Number(product.price || 0).toLocaleString("en-IN")}
                      </p>

                      <span className="flex items-center gap-1 text-xs font-bold text-[#A58A62]">
                        View Details
                        <ArrowUpRight size={14} />
                      </span>

                    </div>

                  </div>

                </button>
              );
            })}

          </div>

        </section>
      )}

      {/* ================================== */}
      {/* GALLERY */}
      {/* ================================== */}

      <section
        id="minimal-gallery"
        className="bg-white px-5 py-9 sm:px-8 sm:py-12 lg:px-10"
      >

        <div className="mb-6 flex items-end justify-between gap-3">

          <div>
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
              A glimpse of my work
            </p>

            <h2 className="mt-2 text-2xl font-black text-[#252525]">
              Gallery
            </h2>
          </div>

          <span className="text-xs font-semibold text-[#8D857A]">
            {galleryImages.length} Photos
          </span>

        </div>

        {galleryImages.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">

            {galleryImages.map((image, index) => (
              <button
                key={`${image.url}-${index}`}
                type="button"
                onClick={() => onGalleryClick(image)}
                className="group relative aspect-[4/3] overflow-hidden rounded-xl bg-[#F0EBE2]"
              >

                <img
                  src={image.url}
                  alt={image.alt || `Gallery ${index + 1}`}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                />

                <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition group-hover:opacity-100">
                  <ArrowUpRight size={25} className="text-white" />
                </div>

              </button>
            ))}

          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-[#DDD6CA] py-12 text-center">

            <ImageIcon
              size={35}
              className="mx-auto text-[#B7AA96]"
            />

            <p className="mt-3 text-sm text-[#918A80]">
              No gallery images added yet.
            </p>

          </div>
        )}

      </section>

      {/* ================================== */}
      {/* CONTACT INFORMATION */}
      {/* ================================== */}

      <section className="px-5 py-9 sm:px-8 sm:py-12 lg:px-10">

        <div className="mb-6">
          <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
            Stay connected
          </p>

          <h2 className="mt-2 text-2xl font-black text-[#252525]">
            Get in Touch
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">

          {[
            {
              Icon: Phone,
              label: "Phone",
              value: phone,
              type: "phone",
            },
            {
              Icon: MessageCircle,
              label: "WhatsApp",
              value: whatsapp,
              type: "whatsapp",
            },
            {
              Icon: Mail,
              label: "Email",
              value: email,
              type: "email",
            },
            {
              Icon: Globe,
              label: "Website",
              value: website,
              type: "website",
            },
            {
              Icon: MapPin,
              label: "Address",
              value: address,
              type: "address",
            },
            {
              Icon: Clock,
              label: "Business Hours",
              value: businessHours,
              type: "hours",
            },
          ]
            .filter((item) => item.value)
            .map((item) => (
              <button
                key={item.type}
                type="button"
                onClick={() => {
                  if (item.type !== "hours") {
                    onContactClick(item.type);
                  }
                }}
                className="flex min-w-0 items-start gap-3 rounded-xl border border-[#EAE6DF] bg-white p-4 text-left transition hover:border-[#C8B79D]"
              >

                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#F0EBE2] text-[#A58A62]">
                  <item.Icon size={17} />
                </div>

                <div className="min-w-0">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[#999084]">
                    {item.label}
                  </p>

                  <p className="mt-1 break-words text-xs font-semibold leading-5 text-[#393630]">
                    {item.value}
                  </p>
                </div>

              </button>
            ))}

        </div>

      </section>

      {/* ================================== */}
      {/* INQUIRY FORM */}
      {/* ================================== */}

      <section
        id="minimal-contact"
        className="border-y border-[#EAE6DF] bg-[#F0EBE2] px-5 py-9 sm:px-8 sm:py-12 lg:px-10"
      >

        <div className="grid items-start gap-8 lg:grid-cols-12">

          <div className="lg:col-span-4">

            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#A58A62]">
              Let's collaborate
            </p>

            <h2 className="mt-2 text-2xl font-black leading-tight text-[#252525] sm:text-3xl">
              Let's Create Something Beautiful
            </h2>

            <p className="mt-4 text-sm leading-7 text-[#827A70]">
              Have a project in mind? I'd love to hear from you. Share your
              ideas and let's make something meaningful together.
            </p>

            <div className="mt-6 flex items-center gap-3">

              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-[#A58A62]">
                <Mail size={17} />
              </div>

              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider text-[#999084]">
                  Get in touch
                </p>

                <p className="text-sm font-bold text-[#393630]">
                  {email || "Send your inquiry"}
                </p>
              </div>

            </div>

          </div>

          <div className="rounded-2xl border border-[#E7E0D5] bg-white p-5 sm:p-7 lg:col-span-8">

            {formSubmitted ? (
              <div className="py-8 text-center">

                <CheckCircle2
                  size={42}
                  className="mx-auto text-[#6D9C7C]"
                />

                <h3 className="mt-4 text-lg font-bold text-[#252525]">
                  Inquiry Submitted Successfully!
                </h3>

                <p className="mt-2 text-sm text-[#918A80]">
                  Thank you for reaching out. I'll get back to you soon.
                </p>

              </div>
            ) : (
              <form
                onSubmit={onFormSubmit}
                className="space-y-4"
              >

                {inquirySubmitError && (
                  <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-600">
                    {inquirySubmitError}
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">

                  <input
                    type="text"
                    required
                    placeholder="Your Name"
                    value={formData.name}
                    disabled={inquirySubmitting}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        name: e.target.value,
                      })
                    }
                    className={inputClass}
                  />

                  <input
                    type="tel"
                    required
                    placeholder="Phone Number"
                    value={formData.phone}
                    disabled={inquirySubmitting}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        phone: e.target.value,
                      })
                    }
                    className={inputClass}
                  />

                </div>

                <input
                  type="email"
                  placeholder="Email Address (Optional)"
                  value={formData.email}
                  disabled={inquirySubmitting}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      email: e.target.value,
                    })
                  }
                  className={inputClass}
                />

                <textarea
                  rows={4}
                  required
                  placeholder="Tell me about your project..."
                  value={formData.message}
                  disabled={inquirySubmitting}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      message: e.target.value,
                    })
                  }
                  className={`${inputClass} resize-none`}
                />

                <button
                  type="submit"
                  disabled={inquirySubmitting}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-[#252525] py-3.5 text-sm font-bold text-white transition hover:bg-[#A58A62] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {inquirySubmitting ? (
                    "Submitting..."
                  ) : (
                    <>
                      <Send size={16} />
                      Send Inquiry
                    </>
                  )}
                </button>

              </form>
            )}

          </div>

        </div>

      </section>

      {/* ================================== */}
      {/* QR CODE */}
      {/* ================================== */}

      {qrTargetUrl && (
        <section className="bg-white px-5 py-8 text-center sm:px-8">

          <h2 className="text-lg font-bold text-[#252525]">
            Scan My Digital Profile
          </h2>

          <p className="mt-1 text-xs text-[#918A80]">
            Save my business details with a quick scan
          </p>

          <div className="mx-auto mt-4 flex w-fit items-center justify-center rounded-xl border border-[#EAE6DF] bg-white p-3">

            {qrFetching ? (
              <p className="p-8 text-xs text-[#918A80]">
                Loading QR...
              </p>
            ) : (
              <QRCodeCanvas
                id="minimal-luxury-qr"
                value={qrTargetUrl}
                size={150}
                level="H"
                includeMargin
              />
            )}

          </div>

          {!qrFetching && (
            <a
              href={`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(qrTargetUrl)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-[#A58A62] hover:text-[#252525]"
            >
              <Download size={14} />
              Download QR Code
            </a>
          )}

        </section>
      )}

      {/* ================================== */}
      {/* FOOTER */}
      {/* ================================== */}

      <footer className="border-t border-[#EAE6DF] bg-white px-5 py-7 sm:px-8 lg:px-10">

        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">

          <div className="text-center sm:text-left">

            <p className="text-xl font-black tracking-tight text-[#252525]">
              Bio<span className="text-[#A58A62]">.</span>
            </p>

            <p className="mt-1 text-[10px] text-[#928A7F]">
              Clean. Elegant. Sophisticated.
            </p>

          </div>

          <div className="flex flex-wrap items-center justify-center gap-4">

            {[
              ["Home", "#minimal-home"],
              ["About", "#minimal-about"],
              ["Products", "#minimal-products"],
              ["Gallery", "#minimal-gallery"],
              ["Contact", "#minimal-contact"],
            ].map(([label, href]) => (
              <a
                key={label}
                href={href}
                className="text-[11px] font-semibold text-[#777168] transition hover:text-[#A58A62]"
              >
                {label}
              </a>
            ))}

          </div>

          <p className="text-[10px] text-[#A09A90]">
            © {new Date().getFullYear()} {name || businessName}. All rights reserved.
          </p>

        </div>

        <div className="mt-5 border-t border-[#F0ECE6] pt-4 text-center">

          <p className="text-[10px] text-[#A09A90]">
            Powered by{" "}
            <span className="font-bold text-[#A58A62]">
              BioWebsite
            </span>
          </p>

        </div>

      </footer>

    </div>
  );
};

export default MinimalLuxury;
