import React from "react";
import { QRCodeCanvas } from "qrcode.react";
import {
  FaArrowRight,
  FaArrowUpRightFromSquare,
  FaCheck,
  FaClock,
  FaEnvelope,
  FaFacebookF,
  FaGlobe,
  FaInstagram,
  FaLinkedinIn,
  FaLocationDot,
  FaPhone,
  FaQrcode,
  FaShareNodes,
  FaWhatsapp,
  FaXTwitter,
  FaYoutube,
} from "react-icons/fa6";

const FreelancerPro = ({
  businessInfo = {},
  visibleButtons = [],
  socialLinks = [],
  productList = [],
  galleryImages = [],
  qrTargetUrl = "",
  qrFetching = false,
  formData = { name: "", phone: "", email: "", message: "" },
  setFormData = () => {},
  onFormSubmit = () => {},
  inquirySubmitting = false,
  inquirySubmitError = null,
  formSubmitted = false,
  onConfiguredButton = () => {},
  onShare = () => {},
  onOpenQr = () => {},
  onProductClick = () => {},
  onGalleryClick = () => {},
  onContactClick = () => {},
}) => {
  const {
    name = "Your Name",
    role = "Creative Professional",
    location = "",
    about = "",
    phone = "",
    whatsapp = "",
    email = "",
    website = "",
    address = "",
    logo = "",
    avatar = "",
    banner = "",
    industry = "",
    businessName = "",
    businessHours = "",
    isVerified = false,
  } = businessInfo;

  const displayName = name || businessName || "Your Name";
  const displayRole = role || industry || "Creative Professional";

  const getImageUrl = (image) => {
    if (!image) return "";

    if (typeof image === "string") return image;

    return image.url || image.imageUrl || image.src || "";
  };

  const getProductImage = (product) => {
    if (!product) return "";

    if (product.images?.length) {
      return getImageUrl(product.images[0]);
    }

    return getImageUrl(product.image);
  };

  const getSocialIcon = (platform) => {
    const value = String(platform || "").toLowerCase();

    if (value.includes("instagram")) return <FaInstagram />;
    if (value.includes("facebook")) return <FaFacebookF />;
    if (value.includes("linkedin")) return <FaLinkedinIn />;
    if (value.includes("youtube")) return <FaYoutube />;
    if (value.includes("twitter") || value.includes("x.com")) {
      return <FaXTwitter />;
    }

    return <FaGlobe />;
  };

  const profileImage = getImageUrl(avatar || logo);
  const heroImage = getImageUrl(banner);

  const handleContact = (type) => {
    onContactClick(type);
  };

  return (
    <div className="min-h-screen bg-[#f6f7fb] text-[#171923]">
      {/* =====================================================
          HEADER
      ===================================================== */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            {profileImage ? (
              <img
                src={profileImage}
                alt={displayName}
                className="h-11 w-11 rounded-full object-cover ring-2 ring-slate-100"
              />
            ) : (
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#171923] text-sm font-black text-white">
                {displayName.charAt(0).toUpperCase()}
              </div>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p className="truncate text-sm font-black">
                  {displayName}
                </p>

                {isVerified && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#7c3aed] text-[8px] text-white">
                    <FaCheck />
                  </span>
                )}
              </div>

              <p className="truncate text-xs text-slate-500">
                {displayRole}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onShare}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 transition hover:border-[#7c3aed] hover:bg-[#7c3aed] hover:text-white"
            >
              <FaShareNodes />
            </button>

            <button
              type="button"
              onClick={onOpenQr}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 transition hover:border-[#7c3aed] hover:bg-[#7c3aed] hover:text-white"
            >
              <FaQrcode />
            </button>
          </div>
        </div>
      </header>

      {/* =====================================================
          HERO
      ===================================================== */}
      <section className="relative overflow-hidden bg-white">
        <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-purple-200/50 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-indigo-200/50 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-20">
          <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
            {/* LEFT */}
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-purple-50 px-4 py-2 text-xs font-bold uppercase tracking-[0.15em] text-[#7c3aed]">
                <span className="h-2 w-2 rounded-full bg-[#7c3aed]" />
                Available for Work
              </div>

              <h1 className="mt-6 max-w-3xl text-5xl font-black leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
                Hi, I'm{" "}
                <span className="text-[#7c3aed]">{displayName}</span>
              </h1>

              <p className="mt-5 text-xl font-bold text-slate-600">
                {displayRole}
              </p>

              {about && (
                <p className="mt-6 max-w-2xl text-sm leading-8 text-slate-500 sm:text-base">
                  {about}
                </p>
              )}

              {location && (
                <div className="mt-5 flex items-center gap-2 text-sm font-medium text-slate-500">
                  <FaLocationDot className="text-[#7c3aed]" />
                  {location}
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-3">
                {phone && (
                  <button
                    type="button"
                    onClick={() => handleContact("phone")}
                    className="inline-flex items-center gap-2 rounded-xl bg-[#171923] px-6 py-3.5 text-sm font-bold text-white transition hover:bg-[#7c3aed]"
                  >
                    <FaPhone />
                    Let's Talk
                  </button>
                )}

                {whatsapp && (
                  <button
                    type="button"
                    onClick={() => handleContact("whatsapp")}
                    className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-6 py-3.5 text-sm font-bold text-[#171923] transition hover:border-[#7c3aed] hover:text-[#7c3aed]"
                  >
                    <FaWhatsapp />
                    WhatsApp
                  </button>
                )}
              </div>
            </div>

            {/* RIGHT */}
            <div className="relative">
              <div className="absolute -inset-5 rounded-[2rem] bg-gradient-to-br from-purple-200/50 to-indigo-200/50 blur-2xl" />

              <div className="relative overflow-hidden rounded-[2rem] border border-white bg-white p-3 shadow-2xl">
                {heroImage ? (
                  <img
                    src={heroImage}
                    alt={displayName}
                    className="h-[430px] w-full rounded-[1.5rem] object-cover"
                  />
                ) : profileImage ? (
                  <img
                    src={profileImage}
                    alt={displayName}
                    className="h-[430px] w-full rounded-[1.5rem] object-cover"
                  />
                ) : (
                  <div className="flex h-[430px] items-center justify-center rounded-[1.5rem] bg-gradient-to-br from-[#171923] to-[#7c3aed]">
                    <span className="text-[180px] font-black text-white/10">
                      {displayName.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}

                <div className="absolute bottom-8 left-8 right-8 rounded-2xl border border-white/20 bg-black/50 p-4 text-white backdrop-blur-xl">
                  <p className="text-xs uppercase tracking-wider text-white/60">
                    Professional
                  </p>

                  <p className="mt-1 font-bold">{displayRole}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT CARDS
      ===================================================== */}
      <section className="mx-auto max-w-7xl px-5 py-8 sm:px-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {phone && (
            <button
              type="button"
              onClick={() => handleContact("phone")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-lg"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-[#7c3aed] transition group-hover:bg-[#7c3aed] group-hover:text-white">
                <FaPhone />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400">
                Phone
              </p>

              <p className="mt-1 truncate text-sm font-bold">
                {phone}
              </p>
            </button>
          )}

          {email && (
            <button
              type="button"
              onClick={() => handleContact("email")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-lg"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-[#7c3aed] transition group-hover:bg-[#7c3aed] group-hover:text-white">
                <FaEnvelope />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400">
                Email
              </p>

              <p className="mt-1 truncate text-sm font-bold">
                {email}
              </p>
            </button>
          )}

          {website && (
            <button
              type="button"
              onClick={() => handleContact("website")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-lg"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-[#7c3aed] transition group-hover:bg-[#7c3aed] group-hover:text-white">
                <FaGlobe />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400">
                Website
              </p>

              <p className="mt-1 truncate text-sm font-bold">
                {website}
              </p>
            </button>
          )}

          {(address || location) && (
            <button
              type="button"
              onClick={() => handleContact("address")}
              className="group rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-lg"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-[#7c3aed] transition group-hover:bg-[#7c3aed] group-hover:text-white">
                <FaLocationDot />
              </div>

              <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400">
                Location
              </p>

              <p className="mt-1 line-clamp-2 text-sm font-bold">
                {address || location}
              </p>
            </button>
          )}
        </div>
      </section>

      {/* =====================================================
          QUICK LINKS
      ===================================================== */}
      {visibleButtons.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="mb-7">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
              Services & Links
            </p>

            <h2 className="mt-2 text-3xl font-black">
              What I Can Help With
            </h2>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {visibleButtons.map((button, index) => (
              <button
                key={button._id || button.id || index}
                type="button"
                onClick={() => onConfiguredButton(button)}
                className="group flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-5 py-5 text-left transition hover:-translate-y-1 hover:border-purple-200 hover:shadow-lg"
              >
                <span className="font-bold">
                  {button.label || "Service"}
                </span>

                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-purple-50 text-[#7c3aed] transition group-hover:bg-[#7c3aed] group-hover:text-white">
                  <FaArrowRight />
                </span>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* =====================================================
          ABOUT
      ===================================================== */}
      {about && (
        <section className="bg-[#171923] text-white">
          <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
            <div className="grid gap-10 lg:grid-cols-[0.7fr_1.3fr]">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-purple-300">
                  About Me
                </p>

                <h2 className="mt-3 text-4xl font-black">
                  Building meaningful work.
                </h2>
              </div>

              <div>
                <p className="text-base leading-8 text-white/65">
                  {about}
                </p>

                {industry && (
                  <div className="mt-6 inline-flex rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white/80">
                    {industry}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          PRODUCTS / SERVICES
      ===================================================== */}
      {productList.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
          <div className="mb-8 flex items-end justify-between gap-5">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
                My Work
              </p>

              <h2 className="mt-2 text-3xl font-black sm:text-4xl">
                Featured Work
              </h2>
            </div>

            <p className="hidden text-sm text-slate-400 sm:block">
              {productList.length} Items
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {productList.map((product, index) => {
              const image = getProductImage(product);

              return (
                <button
                  key={product._id || product.id || index}
                  type="button"
                  onClick={() => onProductClick(product)}
                  className="group overflow-hidden rounded-3xl border border-slate-200 bg-white text-left shadow-sm transition hover:-translate-y-2 hover:shadow-xl"
                >
                  <div className="relative h-64 overflow-hidden bg-slate-100">
                    {image ? (
                      <img
                        src={image}
                        alt={product.name || "Work"}
                        className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-sm text-slate-400">
                        No Image
                      </div>
                    )}

                    <div className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-lg">
                      <FaArrowUpRightFromSquare className="text-[#7c3aed]" />
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="text-lg font-black">
                        {product.name || "Project"}
                      </h3>

                      {product.price !== undefined &&
                        product.price !== null &&
                        product.price !== "" && (
                          <span className="font-black text-[#7c3aed]">
                            ₹{product.price}
                          </span>
                        )}
                    </div>

                    {product.description && (
                      <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">
                        {product.description}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* =====================================================
          GALLERY
      ===================================================== */}
      {galleryImages.length > 0 && (
        <section className="bg-white">
          <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
            <div className="mb-8">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
                Portfolio
              </p>

              <h2 className="mt-2 text-3xl font-black sm:text-4xl">
                Selected Moments
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {galleryImages.map((image, index) => {
                const imageUrl = getImageUrl(image);

                return (
                  <button
                    key={image._id || image.id || index}
                    type="button"
                    onClick={() => onGalleryClick(image)}
                    className="group relative aspect-square overflow-hidden rounded-2xl bg-slate-100"
                  >
                    {imageUrl && (
                      <img
                        src={imageUrl}
                        alt={image.alt || "Portfolio"}
                        className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                      />
                    )}

                    <div className="absolute inset-0 bg-[#7c3aed]/0 transition group-hover:bg-[#7c3aed]/20" />
                  </button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          SOCIAL LINKS
      ===================================================== */}
      {socialLinks.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 text-center shadow-sm">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
              Social Presence
            </p>

            <h2 className="mt-2 text-3xl font-black">
              Find Me Online
            </h2>

            <div className="mt-7 flex flex-wrap justify-center gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={social._id || social.id || index}
                  href={social.url || "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="flex h-12 w-12 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-[#171923] transition hover:-translate-y-1 hover:bg-[#7c3aed] hover:text-white"
                  title={social.platform || "Social"}
                >
                  {getSocialIcon(social.platform)}
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          BUSINESS HOURS
      ===================================================== */}
      {businessHours && (
        <section className="mx-auto max-w-7xl px-5 pb-14 sm:px-8">
          <div className="flex items-start gap-4 rounded-3xl bg-purple-50 p-7">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white text-[#7c3aed] shadow-sm">
              <FaClock />
            </div>

            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
                Working Hours
              </p>

              <p className="mt-2 whitespace-pre-line text-sm leading-7 text-slate-600">
                {businessHours}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================
          QR
      ===================================================== */}
      <section className="mx-auto max-w-7xl px-5 pb-16 sm:px-8">
        <div className="grid items-center gap-8 overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#171923] to-[#34205e] p-8 sm:p-10 lg:grid-cols-[1fr_auto]">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-purple-300">
              Digital Profile
            </p>

            <h2 className="mt-2 text-3xl font-black text-white sm:text-4xl">
              Let's Connect
            </h2>

            <p className="mt-4 max-w-xl text-sm leading-7 text-white/60">
              Scan the QR code or share this profile with someone who needs
              your services.
            </p>

            <button
              type="button"
              onClick={onOpenQr}
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#7c3aed] px-5 py-3 text-sm font-bold text-white transition hover:bg-white hover:text-[#171923]"
            >
              <FaQrcode />
              Open QR
            </button>
          </div>

          <div className="flex justify-center">
            <div className="rounded-3xl bg-white p-4">
              {qrFetching ? (
                <div className="flex h-40 w-40 items-center justify-center text-xs text-slate-400">
                  Loading...
                </div>
              ) : qrTargetUrl ? (
                <QRCodeCanvas
                  value={qrTargetUrl}
                  size={160}
                  includeMargin
                />
              ) : (
                <div className="flex h-40 w-40 items-center justify-center text-center text-xs text-slate-400">
                  QR unavailable
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT FORM
      ===================================================== */}
      <section className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.7fr_1.3fr]">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#7c3aed]">
                Contact Me
              </p>

              <h2 className="mt-3 text-4xl font-black">
                Have a project in mind?
              </h2>

              <p className="mt-5 text-sm leading-8 text-slate-500">
                Tell me a little about what you need and I will get back to
                you as soon as possible.
              </p>
            </div>

            <form
              onSubmit={onFormSubmit}
              className="rounded-3xl border border-slate-200 bg-[#f8f8fb] p-6 sm:p-8"
            >
              {formSubmitted ? (
                <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-purple-100 text-xl text-[#7c3aed]">
                    <FaCheck />
                  </div>

                  <h3 className="mt-5 text-xl font-black">
                    Thanks for reaching out!
                  </h3>

                  <p className="mt-2 text-sm text-slate-500">
                    Your inquiry has been submitted successfully.
                  </p>
                </div>
              ) : (
                <>
                  {inquirySubmitError && (
                    <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
                      {inquirySubmitError}
                    </div>
                  )}

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                        Name
                      </label>

                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                        placeholder="Your name"
                        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#7c3aed]"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                        Phone
                      </label>

                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            phone: e.target.value,
                          }))
                        }
                        placeholder="Phone number"
                        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#7c3aed]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                        Email
                      </label>

                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            email: e.target.value,
                          }))
                        }
                        placeholder="Email address"
                        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#7c3aed]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">
                        Message
                      </label>

                      <textarea
                        rows={5}
                        value={formData.message}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            message: e.target.value,
                          }))
                        }
                        placeholder="Tell me about your project..."
                        className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#7c3aed]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={inquirySubmitting}
                    className="mt-6 w-full rounded-xl bg-[#171923] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#7c3aed] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {inquirySubmitting ? "Sending..." : "Send Message"}
                  </button>
                </>
              )}
            </form>
          </div>
        </div>
      </section>

      {/* =====================================================
          FOOTER
      ===================================================== */}
      <footer className="bg-[#171923] text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-5 py-8 text-center sm:flex-row sm:px-8 sm:text-left">
          <div>
            <p className="font-black">{displayName}</p>
            <p className="mt-1 text-xs text-white/40">
              {industry || displayRole}
            </p>
          </div>

          <p className="text-xs text-white/40">
            Digital Business Profile
          </p>
        </div>
      </footer>
    </div>
  );
};

export default FreelancerPro;