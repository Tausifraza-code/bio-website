import { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import Home from "./pages/Home";
import AuthPage from "./pages/AuthPage";
import About from "./pages/About";
import Contact from "./pages/Contact";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import CardPreview from "./pages/CardPreview";
import Dashboard from "./pages/Dashboard";
import RazorpayTest from "./pages/RazorpayTest";
import ProfileLayouts from "./pages/ProfileLayouts";

import DashboardLayout from "./layout/DashboardLayout";
import PublicPageLayout from "./layout/PublicPageLayout";
import PrivateRoute from "./components/PrivateRoute";

import EditProfile from "./pages/EditProfile";
import Leads from "./pages/Leads";
import ManageProducts from "./pages/ManageProducts";
import Mini from "./pages/Mini";
import QrCode from "./pages/Qr";
import Refer from "./pages/Refer";
import SocialCard from "./pages/SocialCard";
import ContactButtons from "./pages/ContactButtons";
import WebsiteTheme from "./pages/WebsiteTheme";
import UpiPaymentSettings from "./pages/UpiPaymentSettings";
import TestQRGenerator from "./pages/TestQRGenerator";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Gallery from "./pages/Gallery";
import Review from "./pages/Review";

// Admin imports
import AdminLayout from "./admin/components/AdminLayout";
import AdminDashboard from "./admin/pages/AdminDashboard";
import AdminLogin from "./admin/pages/AdminLogin";
import AdminUsers from "./admin/pages/AdminUsers";
import AdminReferrals from "./admin/pages/AdminReferrals";
import AdminQRManagement from "./admin/pages/AdminQRManagement";
import AdminPlans from "./admin/pages/AdminPlans";
import AdminOrders from "./admin/pages/AdminOrders";
import AdminUserProfile from "./admin/pages/AdminUserProfile";
import AdminSettings from "./admin/pages/AdminSettings";

function App() {
  useEffect(() => {
    const isAdminRoute = window.location.pathname.startsWith("/admin");

    try {
      if (isAdminRoute) {
        const adminTheme = localStorage.getItem("adminTheme") || "light";
        document.documentElement.dataset.theme = adminTheme;
      } else {
        const bioTheme = localStorage.getItem("bio-theme") || "dark";
        document.documentElement.dataset.theme = bioTheme;
      }
    } catch {
      document.documentElement.dataset.theme = "dark";
    }
  }, []);

  return (
    <>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 2500,
          style: {
            borderRadius: "12px",
            fontSize: "14px",
          },
        }}
      />

      <Routes>
        {/* ================================== */}
        {/* PUBLIC ROUTES */}
        {/* ================================== */}

        <Route path="/" element={<Home />} />
        <Route
          path="/about"
          element={
            <PublicPageLayout>
              <About />
            </PublicPageLayout>
          }
        />
        <Route
          path="/contact"
          element={
            <PublicPageLayout>
              <Contact />
            </PublicPageLayout>
          }
        />
        <Route
          path="/privacy-policy"
          element={
            <PublicPageLayout>
              <PrivacyPolicy />
            </PublicPageLayout>
          }
        />

        {/* Authentication */}
        <Route path="/login" element={<AuthPage />} />
        <Route path="/register" element={<AuthPage />} />

        {/* Public Preview */}
        <Route path="/preview" element={<CardPreview />} />
        <Route path="/card-preview" element={<CardPreview />} />
        <Route path="/card-preview/:subdomain" element={<CardPreview />} />

        {/* Payment Testing */}
        <Route path="/razorpay-test" element={<RazorpayTest />} />

        {/* Password Reset */}
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* ================================== */}
        {/* PRIVATE ROUTES */}
        {/* ================================== */}

        <Route element={<PrivateRoute />}>
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />

            <Route path="/qr-test" element={<TestQRGenerator />} />

            <Route path="/editprofile" element={<EditProfile />} />

            <Route path="/leads" element={<Leads />} />

            <Route path="/manageproducts" element={<ManageProducts />} />

            <Route path="/profile-layouts" element={<ProfileLayouts />} />

            <Route path="/gallery" element={<Gallery />} />

            <Route path="/mini" element={<Mini />} />

            <Route path="/payment" element={<Navigate to="/mini" replace />} />

            <Route path="/theme" element={<WebsiteTheme />} />

            <Route path="/qrcode" element={<QrCode />} />

            <Route path="/refer" element={<Refer />} />

            <Route path="/review" element={<Review />} />

            <Route path="/contact-buttons" element={<ContactButtons />} />

            <Route path="/socialcard" element={<SocialCard />} />

            <Route path="/upi-payments" element={<UpiPaymentSettings />} />
          </Route>
        </Route>

        {/* ================================== */}
        {/* ADMIN ROUTES */}
        {/* ================================== */}

        {/* Admin Login - Public */}
        <Route path="/admin/login" element={<AdminLogin />} />

        {/* Admin Dashboard */}
        <Route element={<AdminLayout />}>
          <Route path="/admin" element={<AdminDashboard />} />

          <Route path="/admin/users" element={<AdminUsers />} />

          <Route path="/admin/referrals" element={<AdminReferrals />} />

          <Route path="/admin/qr-management" element={<AdminQRManagement />} />

          <Route path="/admin/plans" element={<AdminPlans />} />

          <Route path="/admin/orders" element={<AdminOrders />} />

          <Route path="/admin/users/:userId" element={<AdminUserProfile />} />

          <Route path="/admin/settings" element={<AdminSettings />} />
        </Route>

        {/* ================================== */}
        {/* UNKNOWN URL */}
        {/* ================================== */}

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

export default App;
